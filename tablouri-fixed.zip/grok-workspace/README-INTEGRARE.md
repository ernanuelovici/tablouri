# Integrare: link-uri partajabile (fără cont)

## Fișiere din acest pachet

```
migrations/0002_shared_boards.sql     → NOU (copiază)
src/lib/share.ts                      → NOU (copiază)
src/lib/share-client.ts               → NOU (copiază)
src/store/board-store.ts              → ÎNLOCUIEȘTE fișierul existent
src/components/board/header.tsx       → ÎNLOCUIEȘTE fișierul existent
src/components/board/canvas.tsx       → ÎNLOCUIEȘTE (opțional, fix pinch-zoom)
.grok/app-env.json                    → ÎNLOCUIEȘTE (activează database)
```

## Pași

1. Extrage arhiva `share-feature.zip` pe calculator.

2. Din folderul proiectului tău (cel cu `package.json`), copiază astfel:

```bash
# din folderul proiectului:
cp calea/catre/share-feature/migrations/0002_shared_boards.sql  migrations/
cp calea/catre/share-feature/src/lib/share.ts                   src/lib/
cp calea/catre/share-feature/src/lib/share-client.ts            src/lib/
cp calea/catre/share-feature/src/store/board-store.ts           src/store/
cp calea/catre/share-feature/src/components/board/header.tsx    src/components/board/
cp calea/catre/share-feature/.grok/app-env.json                 .grok/

# opțional – fix pinch-zoom:
cp calea/catre/share-feature/src/components/board/canvas.tsx    src/components/board/
```

3. Pornește aplicația:

```bash
npm install
npm run dev
```

4. Test:
   - Adaugă o notă sau o imagine
   - Apasă iconița de **link** (sus, lângă ajutor)
   - Copiază URL-ul (`?s=...`)
   - Deschide-l într-o fereastră/incognito → același tablou

## Note

- Link-urile funcționează pe deplin după **deploy** (Vercel + Neon).
- În preview local, baza e PGLite (în memorie) – link-urile funcționează
  doar pe aceeași sesiune de server.
- Oricine are link-ul poate edita (fără cont).
- Tablouri foarte mari (multe imagini) pot eșua la upload (~3.5 MB limit).
