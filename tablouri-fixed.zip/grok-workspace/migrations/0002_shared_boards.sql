-- Public shareable boards (no accounts). Anyone with the id can read/write.
CREATE TABLE IF NOT EXISTS shared_boards (
  id TEXT PRIMARY KEY,
  title TEXT NOT NULL DEFAULT '',
  payload JSONB NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS shared_boards_updated_at_idx
  ON shared_boards (updated_at DESC);
