import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

/** Max payload ~3.5MB JSON to stay under typical body limits. */
const MAX_PAYLOAD_CHARS = 3_500_000;

/** Loose but serializable board snapshot for public shares. */
const sharePayloadSchema = z.object({
  title: z.string().max(200),
  itemsJson: z.string(),
  pan: z.object({ x: z.number(), y: z.number() }),
  zoom: z.number(),
  blobs: z.record(z.string(), z.string()),
});

export type SharePayload = z.infer<typeof sharePayloadSchema>;

function makeShareId(): string {
  const bytes = new Uint8Array(9);
  crypto.getRandomValues(bytes);
  let s = "";
  for (const b of bytes) s += b.toString(36).padStart(2, "0");
  return s.slice(0, 12);
}

export const createShare = createServerFn({ method: "POST" })
  .validator((data: unknown) => sharePayloadSchema.parse(data))
  .handler(async ({ data }): Promise<{ id: string }> => {
    const json = JSON.stringify(data);
    if (json.length > MAX_PAYLOAD_CHARS) {
      throw new Error(
        "Tabloul e prea mare pentru link (imagini prea multe/mari). Încearcă mai puține imagini.",
      );
    }
    const { getSql } = await import("@/lib/db");
    const sql = await getSql();
    for (let attempt = 0; attempt < 5; attempt++) {
      const id = makeShareId();
      try {
        await sql.query(
          `insert into shared_boards (id, title, payload) values ($1, $2, $3::jsonb)`,
          [id, data.title, json],
        );
        return { id };
      } catch {
        // unique violation → retry
      }
    }
    throw new Error("Nu am putut crea link-ul. Încearcă din nou.");
  });

export const getShare = createServerFn({ method: "GET" })
  .validator((data: unknown) =>
    z.object({ id: z.string().min(4).max(32) }).parse(data),
  )
  .handler(async ({ data }): Promise<SharePayload | null> => {
    const { getSql } = await import("@/lib/db");
    const sql = await getSql();
    const rows = await sql.query<{
      title: string;
      payload: string | SharePayload;
    }>(`select title, payload from shared_boards where id = $1 limit 1`, [
      data.id,
    ]);
    const row = rows[0];
    if (!row) return null;
    const raw =
      typeof row.payload === "string" ? JSON.parse(row.payload) : row.payload;
    return sharePayloadSchema.parse(raw);
  });

export const updateShare = createServerFn({ method: "POST" })
  .validator((data: unknown) =>
    z
      .object({
        id: z.string().min(4).max(32),
        payload: sharePayloadSchema,
      })
      .parse(data),
  )
  .handler(async ({ data }): Promise<{ ok: true }> => {
    const json = JSON.stringify(data.payload);
    if (json.length > MAX_PAYLOAD_CHARS) {
      throw new Error(
        "Tabloul e prea mare pentru salvare. Încearcă mai puține imagini.",
      );
    }
    const { getSql } = await import("@/lib/db");
    const sql = await getSql();
    const rows = await sql.query<{ id: string }>(
      `update shared_boards
       set title = $1, payload = $2::jsonb, updated_at = now()
       where id = $3
       returning id`,
      [data.payload.title, json, data.id],
    );
    if (!rows[0]) {
      throw new Error("Link invalid sau expirat.");
    }
    return { ok: true };
  });
