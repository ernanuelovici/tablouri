import { MAX_PDF_PAGES, PIN_MAX_H, PIN_MAX_W } from "@/lib/board-types";

export function isPdfFile(file: File): boolean {
  return (
    file.type === "application/pdf" || file.name.toLowerCase().endsWith(".pdf")
  );
}

export function isImageFile(file: File): boolean {
  if (file.type.startsWith("image/")) return true;
  return /\.(jpe?g|png|webp|gif)$/i.test(file.name);
}

export function fitPinSize(
  width: number,
  height: number,
): { w: number; h: number } {
  const scale = Math.min(PIN_MAX_W / width, PIN_MAX_H / height);
  return {
    w: Math.max(80, Math.round(width * scale)),
    h: Math.max(80, Math.round(height * scale)),
  };
}

export async function fileToJpegBlob(
  file: Blob,
  maxEdge = 1920,
  quality = 0.86,
): Promise<{ blob: Blob; width: number; height: number }> {
  const bitmap = await createImageBitmap(file);
  let { width, height } = bitmap;
  const scale = Math.min(1, maxEdge / Math.max(width, height));
  width = Math.max(1, Math.round(width * scale));
  height = Math.max(1, Math.round(height * scale));
  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext("2d");
  if (!ctx) {
    bitmap.close();
    throw new Error("Canvas is unavailable");
  }
  ctx.fillStyle = "#fffcf7";
  ctx.fillRect(0, 0, width, height);
  ctx.drawImage(bitmap, 0, 0, width, height);
  bitmap.close();
  const blob = await new Promise<Blob>((resolve, reject) => {
    canvas.toBlob(
      (result) =>
        result ? resolve(result) : reject(new Error("Could not encode image")),
      "image/jpeg",
      quality,
    );
  });
  return { blob, width, height };
}

export async function pdfToPageBlobs(file: File): Promise<{
  blob: Blob;
  width: number;
  height: number;
  page: number;
  pageCount: number;
  truncated: boolean;
}[]> {
  const pdfjs = await import("pdfjs-dist");
  const workerMod = await import("pdfjs-dist/build/pdf.worker.min.mjs?url");
  pdfjs.GlobalWorkerOptions.workerSrc = workerMod.default;

  const data = await file.arrayBuffer();
  const doc = await pdfjs.getDocument({ data }).promise;
  const truncated = doc.numPages > MAX_PDF_PAGES;
  const pageCount = Math.min(doc.numPages, MAX_PDF_PAGES);
  const pages: {
    blob: Blob;
    width: number;
    height: number;
    page: number;
    pageCount: number;
    truncated: boolean;
  }[] = [];

  for (let i = 1; i <= pageCount; i += 1) {
    const page = await doc.getPage(i);
    const viewport = page.getViewport({ scale: 1.6 });
    const canvas = document.createElement("canvas");
    canvas.width = Math.max(1, Math.floor(viewport.width));
    canvas.height = Math.max(1, Math.floor(viewport.height));
    const ctx = canvas.getContext("2d");
    if (!ctx) throw new Error("Canvas is unavailable");
    ctx.fillStyle = "#fffcf7";
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    await page.render({
      canvas,
      canvasContext: ctx,
      viewport,
    }).promise;
    const blob = await new Promise<Blob>((resolve, reject) => {
      canvas.toBlob(
        (result) =>
          result ? resolve(result) : reject(new Error("Could not encode page")),
        "image/jpeg",
        0.86,
      );
    });
    pages.push({
      blob,
      width: canvas.width,
      height: canvas.height,
      page: i,
      pageCount: doc.numPages,
      truncated,
    });
  }

  return pages;
}
