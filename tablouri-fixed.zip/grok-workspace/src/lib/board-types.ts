export type ItemType = "image" | "text";

export interface BaseItem {
  id: string;
  x: number;
  y: number;
  w: number;
  h: number;
  z: number;
  rotation: number;
}

export interface ImageItem extends BaseItem {
  type: "image";
  blobId: string;
  name: string;
  source: "upload" | "pdf" | "sample";
  page?: number;
  pageCount?: number;
}

export type TextTone = "cream" | "ink" | "plain";
export type TextVariant = "display" | "note";
export type TextAlign = "left" | "center";

export interface TextItem extends BaseItem {
  type: "text";
  content: string;
  fontSize: number;
  variant: TextVariant;
  tone: TextTone;
  align: TextAlign;
}

export type BoardItem = ImageItem | TextItem;

export interface BoardSnapshot {
  title: string;
  items: BoardItem[];
}

export interface PersistedBoard {
  v: 1;
  title: string;
  items: BoardItem[];
  pan: { x: number; y: number };
  zoom: number;
}

export const ZOOM_MIN = 0.2;
export const ZOOM_MAX = 3;
export const MAX_PDF_PAGES = 12;
export const PIN_MAX_W = 280;
export const PIN_MAX_H = 380;
