import type { BoardItem, PersistedBoard } from "@/lib/board-types";
import { blobGet, blobPut } from "@/lib/idb";
import { createShare, getShare, updateShare, type SharePayload } from "@/lib/share";

async function blobToBase64(blob: Blob): Promise<string> {
  const buffer = await blob.arrayBuffer();
  const bytes = new Uint8Array(buffer);
  let binary = "";
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) {
    binary += String.fromCharCode(...bytes.subarray(i, i + chunk));
  }
  return btoa(binary);
}

function base64ToBlob(base64: string, type = "image/jpeg"): Blob {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return new Blob([bytes], { type });
}

export async function buildSharePayload(state: {
  title: string;
  items: BoardItem[];
  pan: { x: number; y: number };
  zoom: number;
}): Promise<SharePayload> {
  const blobs: Record<string, string> = {};
  for (const item of state.items) {
    if (item.type !== "image") continue;
    if (blobs[item.blobId]) continue;
    const blob = await blobGet(item.blobId);
    if (!blob) continue;
    blobs[item.blobId] = await blobToBase64(blob);
  }
  return {
    title: state.title,
    itemsJson: JSON.stringify(state.items),
    pan: state.pan,
    zoom: state.zoom,
    blobs,
  };
}

export async function applySharePayload(payload: SharePayload): Promise<{
  board: PersistedBoard;
  urls: Record<string, string>;
}> {
  const urls: Record<string, string> = {};
  for (const [blobId, b64] of Object.entries(payload.blobs)) {
    const blob = base64ToBlob(b64);
    await blobPut(blobId, blob);
    urls[blobId] = URL.createObjectURL(blob);
  }
  let items: BoardItem[] = [];
  try {
    items = JSON.parse(payload.itemsJson) as BoardItem[];
  } catch {
    items = [];
  }
  return {
    board: {
      v: 1,
      title: payload.title,
      items,
      pan: payload.pan,
      zoom: payload.zoom,
    },
    urls,
  };
}

export async function publishBoard(state: {
  title: string;
  items: BoardItem[];
  pan: { x: number; y: number };
  zoom: number;
}): Promise<{ id: string; url: string }> {
  const payload = await buildSharePayload(state);
  const { id } = await createShare({ data: payload });
  return { id, url: shareUrlForId(id) };
}

export async function loadSharedBoard(id: string): Promise<{
  board: PersistedBoard;
  urls: Record<string, string>;
} | null> {
  const payload = await getShare({ data: { id } });
  if (!payload) return null;
  return applySharePayload(payload);
}

export async function saveSharedBoard(
  id: string,
  state: {
    title: string;
    items: BoardItem[];
    pan: { x: number; y: number };
    zoom: number;
  },
): Promise<void> {
  const payload = await buildSharePayload(state);
  await updateShare({ data: { id, payload } });
}

export function shareUrlForId(id: string): string {
  if (typeof window === "undefined") return `/?s=${id}`;
  const u = new URL(window.location.href);
  u.search = "";
  u.hash = "";
  u.searchParams.set("s", id);
  return u.toString();
}

export function readShareIdFromUrl(): string | null {
  if (typeof window === "undefined") return null;
  const id = new URL(window.location.href).searchParams.get("s");
  return id && id.length >= 4 ? id : null;
}
