import { ZOOM_MAX, ZOOM_MIN } from "@/lib/board-types";

export function clamp(value: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, value));
}

export function clampZoom(zoom: number): number {
  return clamp(zoom, ZOOM_MIN, ZOOM_MAX);
}

export function screenToWorld(
  clientX: number,
  clientY: number,
  bounds: DOMRect,
  pan: { x: number; y: number },
  zoom: number,
): { x: number; y: number } {
  return {
    x: (clientX - bounds.left - pan.x) / zoom,
    y: (clientY - bounds.top - pan.y) / zoom,
  };
}

export function zoomToward(
  clientX: number,
  clientY: number,
  bounds: DOMRect,
  pan: { x: number; y: number },
  zoom: number,
  nextZoom: number,
): { pan: { x: number; y: number }; zoom: number } {
  const z = clampZoom(nextZoom);
  const world = screenToWorld(clientX, clientY, bounds, pan, zoom);
  return {
    zoom: z,
    pan: {
      x: clientX - bounds.left - world.x * z,
      y: clientY - bounds.top - world.y * z,
    },
  };
}
