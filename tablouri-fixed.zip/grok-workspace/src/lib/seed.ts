import type { BoardItem, TextItem } from "@/lib/board-types";
import { blobPut } from "@/lib/idb";

interface SamplePin {
  src: string;
  name: string;
  x: number;
  y: number;
  w: number;
  h: number;
}

const SAMPLES: SamplePin[] = [
  { src: "/samples/botanicals.jpg", name: "Botanice", x: 80, y: 248, w: 250, h: 333 },
  { src: "/samples/courtyard.jpg", name: "Curte", x: 354, y: 248, w: 360, h: 270 },
  { src: "/samples/paper.jpg", name: "Hârtie", x: 738, y: 248, w: 250, h: 250 },
  { src: "/samples/ceramics.jpg", name: "Ceramica", x: 80, y: 605, w: 250, h: 333 },
  { src: "/samples/harbor.jpg", name: "Port", x: 354, y: 734, w: 400, h: 225 },
];

function textItem(
  partial: Omit<TextItem, "type" | "rotation" | "z"> & { z: number },
): TextItem {
  return {
    type: "text",
    rotation: 0,
    ...partial,
  };
}

export async function buildDemoBoard(): Promise<{
  title: string;
  items: BoardItem[];
  blobs: Record<string, Blob>;
}> {
  const blobs: Record<string, Blob> = {};
  const items: BoardItem[] = [];
  let z = 1;

  items.push(
    textItem({
      id: crypto.randomUUID(),
      x: 80,
      y: 56,
      w: 520,
      h: 92,
      z: z++,
      content: "Tablou",
      fontSize: 72,
      variant: "display",
      tone: "plain",
      align: "left",
    }),
    textItem({
      id: crypto.randomUUID(),
      x: 86,
      y: 148,
      w: 460,
      h: 72,
      z: z++,
      content: "Un panou liber pentru imagini, PDF-uri și note.",
      fontSize: 20,
      variant: "note",
      tone: "plain",
      align: "left",
    }),
  );

  await Promise.all(
    SAMPLES.map(async (sample) => {
      const response = await fetch(sample.src);
      if (!response.ok) return;
      const blob = await response.blob();
      const blobId = crypto.randomUUID();
      blobs[blobId] = blob;
      await blobPut(blobId, blob);
      items.push({
        id: crypto.randomUUID(),
        type: "image",
        blobId,
        name: sample.name,
        source: "sample",
        x: sample.x,
        y: sample.y,
        w: sample.w,
        h: sample.h,
        z: z++,
        rotation: 0,
      });
    }),
  );

  items.push(
    textItem({
      id: crypto.randomUUID(),
      x: 354,
      y: 542,
      w: 280,
      h: 168,
      z: z++,
      content:
        "Lumină caldă, umbre lungi, hârtie crem. Păstrează paleta restrânsă.",
      fontSize: 18,
      variant: "note",
      tone: "cream",
      align: "left",
    }),
    textItem({
      id: crypto.randomUUID(),
      x: 738,
      y: 522,
      w: 250,
      h: 188,
      z: z++,
      content:
        "Trage fișiere pe pânză. Dublu-click pe o notă ca să o editezi.",
      fontSize: 18,
      variant: "note",
      tone: "ink",
      align: "left",
    }),
  );

  return { title: "Moodboard de start", items, blobs };
}
