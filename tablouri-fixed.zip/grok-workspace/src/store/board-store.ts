import { create } from "zustand";
import type {
  BoardItem,
  ImageItem,
  PersistedBoard,
  TextItem,
  TextTone,
} from "@/lib/board-types";
import { blobGet, blobPut, kvGet, kvSet } from "@/lib/idb";
import {
  fileToJpegBlob,
  fitPinSize,
  isImageFile,
  isPdfFile,
  pdfToPageBlobs,
} from "@/lib/files";
import { buildDemoBoard } from "@/lib/seed";
import { clamp, clampZoom } from "@/lib/geometry";

const HISTORY_LIMIT = 50;
const SAVE_KEY = "board-v3";

export interface IngestResult {
  added: number;
  skipped: number;
  truncatedPdf: boolean;
}

interface HistorySnap {
  title: string;
  items: BoardItem[];
}

interface BoardState {
  ready: boolean;
  title: string;
  items: BoardItem[];
  selectedIds: string[];
  pan: { x: number; y: number };
  zoom: number;
  urls: Record<string, string>;
  past: HistorySnap[];
  future: HistorySnap[];
  needsFit: boolean;
  /** Active public share id when opened via ?s=… */
  shareId: string | null;
  hydrate: () => Promise<void>;
  setShareId: (id: string | null) => void;
  loadFromShare: (id: string) => Promise<boolean>;
  setTitle: (title: string) => void;
  setView: (pan: { x: number; y: number }, zoom: number) => void;
  select: (ids: string[], additive?: boolean) => void;
  clearSelection: () => void;
  pushHistory: () => void;
  undo: () => void;
  redo: () => void;
  moveItems: (ids: string[], dx: number, dy: number) => void;
  placeItems: (positions: { id: string; x: number; y: number }[]) => void;
  resizeItem: (
    id: string,
    next: { x: number; y: number; w: number; h: number },
  ) => void;
  addTextAt: (x: number, y: number, tone?: TextTone) => void;
  ingestFiles: (
    files: File[],
    at: { x: number; y: number },
  ) => Promise<IngestResult>;
  ingestBlob: (
    blob: Blob,
    name: string,
    at: { x: number; y: number },
  ) => Promise<void>;
  updateText: (id: string, content: string) => void;
  removeSelected: () => void;
  duplicateSelected: () => void;
  bringToFront: () => void;
  sendToBack: () => void;
  rotateSelected: (delta: number) => void;
  packGrid: () => void;
  fitView: (viewport: { w: number; h: number }) => void;
  markFitted: () => void;
  clearBoard: () => void;
  loadDemo: () => Promise<void>;
}

function cloneItems(items: BoardItem[]): BoardItem[] {
  return items.map((item) => ({ ...item }));
}

function nextZ(items: BoardItem[]): number {
  return items.reduce((max, item) => Math.max(max, item.z), 0) + 1;
}

function uid(): string {
  return crypto.randomUUID();
}

let saveTimer: number | null = null;
let shareSaveTimer: number | null = null;

function queueSave(state: BoardState) {
  if (!state.ready || typeof window === "undefined") return;
  if (saveTimer) window.clearTimeout(saveTimer);
  saveTimer = window.setTimeout(() => {
    const payload: PersistedBoard = {
      v: 1,
      title: state.title,
      items: state.items,
      pan: state.pan,
      zoom: state.zoom,
    };
    void kvSet(SAVE_KEY, payload);
  }, 350);

  // Debounced cloud save when editing a shared board
  if (state.shareId) {
    if (shareSaveTimer) window.clearTimeout(shareSaveTimer);
    const id = state.shareId;
    shareSaveTimer = window.setTimeout(() => {
      void import("@/lib/share-client").then(({ saveSharedBoard }) =>
        saveSharedBoard(id, {
          title: state.title,
          items: state.items,
          pan: state.pan,
          zoom: state.zoom,
        }).catch(() => {
          // Network / size errors — local copy still saved
        }),
      );
    }, 1200);
  }
}

function rememberUrls(blobs: Record<string, Blob>): Record<string, string> {
  const urls: Record<string, string> = {};
  for (const [id, blob] of Object.entries(blobs)) {
    urls[id] = URL.createObjectURL(blob);
  }
  return urls;
}

export const useBoard = create<BoardState>((set, get) => ({
  ready: false,
  title: "Tablou nou",
  items: [],
  selectedIds: [],
  pan: { x: 48, y: 36 },
  zoom: 1,
  urls: {},
  past: [],
  future: [],
  needsFit: false,
  shareId: null,

  setShareId: (id) => set({ shareId: id }),

  loadFromShare: async (id) => {
    try {
      const { loadSharedBoard } = await import("@/lib/share-client");
      const result = await loadSharedBoard(id);
      if (!result) return false;
      set({
        ready: true,
        title: result.board.title || "Tablou partajat",
        items: result.board.items,
        pan: result.board.pan ?? { x: 48, y: 36 },
        zoom: result.board.zoom ?? 1,
        urls: result.urls,
        selectedIds: [],
        past: [],
        future: [],
        needsFit: true,
        shareId: id,
      });
      void kvSet(SAVE_KEY, result.board);
      return true;
    } catch {
      return false;
    }
  },

  hydrate: async () => {
    // Prefer shared link if present in the URL
    try {
      const { readShareIdFromUrl } = await import("@/lib/share-client");
      const shareId = readShareIdFromUrl();
      if (shareId) {
        const ok = await get().loadFromShare(shareId);
        if (ok) return;
      }
    } catch {
      // Fall through to local
    }

    try {
      const saved = await kvGet<PersistedBoard>(SAVE_KEY);
      if (saved?.v === 1 && saved.items?.length) {
        const urls: Record<string, string> = {};
        for (const item of saved.items) {
          if (item.type !== "image") continue;
          const blob = await blobGet(item.blobId);
          if (blob) urls[item.blobId] = URL.createObjectURL(blob);
        }
        set({
          ready: true,
          title: saved.title || "Tablou nou",
          items: saved.items,
          pan: saved.pan ?? { x: 48, y: 36 },
          zoom: saved.zoom ?? 1,
          urls,
          selectedIds: [],
          past: [],
          future: [],
          needsFit: true,
          shareId: null,
        });
        return;
      }
    } catch {
      // Fall through to demo seed.
    }
    await get().loadDemo();
  },

  setTitle: (title) => {
    set({ title });
    queueSave(get());
  },

  setView: (pan, zoom) => {
    set({ pan, zoom: clampZoom(zoom) });
    queueSave(get());
  },

  select: (ids, additive = false) => {
    set((state) => {
      if (!additive) return { selectedIds: ids };
      const next = new Set(state.selectedIds);
      for (const id of ids) {
        if (next.has(id)) next.delete(id);
        else next.add(id);
      }
      return { selectedIds: [...next] };
    });
  },

  clearSelection: () => set({ selectedIds: [] }),

  pushHistory: () => {
    const { title, items, past } = get();
    set({
      past: [...past, { title, items: cloneItems(items) }].slice(-HISTORY_LIMIT),
      future: [],
    });
  },

  undo: () => {
    const { past, future, title, items } = get();
    const prev = past[past.length - 1];
    if (!prev) return;
    set({
      past: past.slice(0, -1),
      future: [...future, { title, items: cloneItems(items) }],
      title: prev.title,
      items: cloneItems(prev.items),
      selectedIds: [],
    });
    queueSave(get());
  },

  redo: () => {
    const { past, future, title, items } = get();
    const next = future[future.length - 1];
    if (!next) return;
    set({
      future: future.slice(0, -1),
      past: [...past, { title, items: cloneItems(items) }],
      title: next.title,
      items: cloneItems(next.items),
      selectedIds: [],
    });
    queueSave(get());
  },

  moveItems: (ids, dx, dy) => {
    if (!dx && !dy) return;
    const idSet = new Set(ids);
    set((state) => ({
      items: state.items.map((item) =>
        idSet.has(item.id) ? { ...item, x: item.x + dx, y: item.y + dy } : item,
      ),
    }));
    queueSave(get());
  },

  placeItems: (positions) => {
    if (!positions.length) return;
    const map = new Map(positions.map((entry) => [entry.id, entry]));
    set((state) => ({
      items: state.items.map((item) => {
        const next = map.get(item.id);
        return next ? { ...item, x: next.x, y: next.y } : item;
      }),
    }));
    queueSave(get());
  },

  resizeItem: (id, next) => {
    set((state) => ({
      items: state.items.map((item) =>
        item.id === id
          ? {
              ...item,
              x: next.x,
              y: next.y,
              w: Math.max(80, next.w),
              h: Math.max(64, next.h),
            }
          : item,
      ),
    }));
    queueSave(get());
  },

  addTextAt: (x, y, tone = "cream") => {
    get().pushHistory();
    const item: TextItem = {
      id: uid(),
      type: "text",
      x,
      y,
      w: 240,
      h: 160,
      z: nextZ(get().items),
      rotation: 0,
      content: "Notă nouă",
      fontSize: 18,
      variant: "note",
      tone,
      align: "left",
    };
    set((state) => ({
      items: [...state.items, item],
      selectedIds: [item.id],
    }));
    queueSave(get());
  },

  ingestFiles: async (files, at) => {
    get().pushHistory();
    let added = 0;
    let skipped = 0;
    let truncatedPdf = false;
    let offset = 0;
    const created: BoardItem[] = [];
    const urls: Record<string, string> = {};

    for (const file of files) {
      try {
        if (isPdfFile(file)) {
          const pages = await pdfToPageBlobs(file);
          if (pages[0]?.truncated) truncatedPdf = true;
          for (const page of pages) {
            const blobId = uid();
            await blobPut(blobId, page.blob);
            urls[blobId] = URL.createObjectURL(page.blob);
            const size = fitPinSize(page.width, page.height);
            const item: ImageItem = {
              id: uid(),
              type: "image",
              blobId,
              name: file.name,
              source: "pdf",
              page: page.page,
              pageCount: page.pageCount,
              x: at.x + offset,
              y: at.y + offset,
              w: size.w,
              h: size.h,
              z: nextZ([...get().items, ...created]),
              rotation: 0,
            };
            created.push(item);
            offset += 28;
            added += 1;
          }
        } else if (isImageFile(file)) {
          const jpeg = await fileToJpegBlob(file);
          const blobId = uid();
          await blobPut(blobId, jpeg.blob);
          urls[blobId] = URL.createObjectURL(jpeg.blob);
          const size = fitPinSize(jpeg.width, jpeg.height);
          const item: ImageItem = {
            id: uid(),
            type: "image",
            blobId,
            name: file.name,
            source: "upload",
            x: at.x + offset,
            y: at.y + offset,
            w: size.w,
            h: size.h,
            z: nextZ([...get().items, ...created]),
            rotation: 0,
          };
          created.push(item);
          offset += 28;
          added += 1;
        } else {
          skipped += 1;
        }
      } catch {
        skipped += 1;
      }
    }

    if (created.length) {
      set((state) => ({
        items: [...state.items, ...created],
        urls: { ...state.urls, ...urls },
        selectedIds: created.map((item) => item.id),
      }));
      queueSave(get());
    }

    return { added, skipped, truncatedPdf };
  },

  ingestBlob: async (blob, name, at) => {
    const file = new File([blob], name, { type: blob.type || "image/jpeg" });
    await get().ingestFiles([file], at);
  },

  updateText: (id, content) => {
    set((state) => ({
      items: state.items.map((item) =>
        item.id === id && item.type === "text" ? { ...item, content } : item,
      ),
    }));
    queueSave(get());
  },

  removeSelected: () => {
    const { selectedIds } = get();
    if (!selectedIds.length) return;
    get().pushHistory();
    const idSet = new Set(selectedIds);
    set((state) => ({
      items: state.items.filter((item) => !idSet.has(item.id)),
      selectedIds: [],
    }));
    queueSave(get());
  },

  duplicateSelected: () => {
    const { selectedIds, items } = get();
    if (!selectedIds.length) return;
    get().pushHistory();
    const idSet = new Set(selectedIds);
    const copies: BoardItem[] = [];
    let z = nextZ(items);
    for (const item of items) {
      if (!idSet.has(item.id)) continue;
      copies.push({
        ...item,
        id: uid(),
        x: item.x + 28,
        y: item.y + 28,
        z: z++,
      });
    }
    set((state) => ({
      items: [...state.items, ...copies],
      selectedIds: copies.map((item) => item.id),
    }));
    queueSave(get());
  },

  bringToFront: () => {
    const { selectedIds, items } = get();
    if (!selectedIds.length) return;
    get().pushHistory();
    const idSet = new Set(selectedIds);
    let z = nextZ(items);
    set({
      items: items.map((item) =>
        idSet.has(item.id) ? { ...item, z: z++ } : item,
      ),
    });
    queueSave(get());
  },

  sendToBack: () => {
    const { selectedIds, items } = get();
    if (!selectedIds.length) return;
    get().pushHistory();
    const idSet = new Set(selectedIds);
    const minZ =
      items.reduce((min, item) => Math.min(min, item.z), Number.POSITIVE_INFINITY) -
      selectedIds.length;
    let z = minZ;
    set({
      items: items.map((item) =>
        idSet.has(item.id) ? { ...item, z: z++ } : item,
      ),
    });
    queueSave(get());
  },

  rotateSelected: (delta) => {
    const { selectedIds } = get();
    if (!selectedIds.length) return;
    get().pushHistory();
    const idSet = new Set(selectedIds);
    set((state) => ({
      items: state.items.map((item) =>
        idSet.has(item.id)
          ? { ...item, rotation: item.rotation + delta }
          : item,
      ),
    }));
    queueSave(get());
  },

  packGrid: () => {
    const { items } = get();
    if (!items.length) return;
    get().pushHistory();
    const colWidth = 250;
    const gap = 24;
    const cols = 4;
    const heights = Array.from({ length: cols }, () => 0);
    const originX = 80;
    const originY = 80;
    const packed = [...items]
      .sort((a, b) => a.z - b.z)
      .map((item) => {
        const scale = colWidth / item.w;
        const w = colWidth;
        const h = Math.max(80, Math.round(item.h * scale));
        let col = 0;
        for (let i = 1; i < cols; i += 1) {
          if (heights[i]! < heights[col]!) col = i;
        }
        const x = originX + col * (colWidth + gap);
        const y = originY + heights[col]!;
        heights[col]! += h + gap;
        return { ...item, x, y, w, h, rotation: 0 };
      });
    set({ items: packed, selectedIds: [] });
    queueSave(get());
  },

  fitView: (viewport) => {
    const { items } = get();
    const pad = viewport.w < 640 ? 36 : 88;
    if (!items.length) {
      set({ pan: { x: 48, y: 36 }, zoom: 1 });
      queueSave(get());
      return;
    }
    let minX = Infinity;
    let minY = Infinity;
    let maxX = -Infinity;
    let maxY = -Infinity;
    for (const item of items) {
      minX = Math.min(minX, item.x);
      minY = Math.min(minY, item.y);
      maxX = Math.max(maxX, item.x + item.w);
      maxY = Math.max(maxY, item.y + item.h);
    }
    const w = Math.max(1, maxX - minX);
    const h = Math.max(1, maxY - minY);
    const zoom = clampZoom(
      Math.min((viewport.w - pad * 2) / w, (viewport.h - pad * 2) / h, 1.25),
    );
    set({
      zoom,
      pan: {
        x: (viewport.w - w * zoom) / 2 - minX * zoom,
        y: (viewport.h - h * zoom) / 2 - minY * zoom,
      },
    });
    queueSave(get());
  },

  markFitted: () => set({ needsFit: false }),

  clearBoard: () => {
    get().pushHistory();
    set({ items: [], selectedIds: [], title: "Tablou nou" });
    queueSave(get());
  },

  loadDemo: async () => {
    try {
      const demo = await buildDemoBoard();
      const urls = rememberUrls(demo.blobs);
      set({
        ready: true,
        title: demo.title,
        items: demo.items,
        urls: { ...get().urls, ...urls },
        selectedIds: [],
        pan: { x: 36, y: 24 },
        zoom: 0.92,
        past: [],
        future: [],
        needsFit: true,
      });
      queueSave(get());
    } catch {
      set({
        ready: true,
        title: "Tablou nou",
        items: [],
        selectedIds: [],
        pan: { x: 48, y: 36 },
        zoom: 1,
        needsFit: false,
      });
    }
  },
}));

export function selectedItems(state: BoardState): BoardItem[] {
  const idSet = new Set(state.selectedIds);
  return state.items.filter((item) => idSet.has(item.id));
}

export function itemById(state: BoardState, id: string): BoardItem | undefined {
  return state.items.find((item) => item.id === id);
}

export { clamp };
