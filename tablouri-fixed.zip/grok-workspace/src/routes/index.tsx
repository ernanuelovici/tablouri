import { createFileRoute } from "@tanstack/react-router";
import { BoardApp } from "@/components/board/board-app";

export const Route = createFileRoute("/")({
  ssr: false,
  component: Home,
});

function Home() {
  return <BoardApp />;
}
