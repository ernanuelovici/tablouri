import { Slot } from "@radix-ui/react-slot";
import { cva, type VariantProps } from "class-variance-authority";
import type { ButtonHTMLAttributes } from "react";
import { cn } from "@/lib/utils";

const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 whitespace-nowrap font-medium transition-[color,background-color,box-shadow,transform,opacity] duration-150 ease-out focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-bg disabled:pointer-events-none disabled:opacity-40 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0",
  {
    variants: {
      variant: {
        default: "bg-primary text-primary-fg hover:bg-primary/90",
        secondary:
          "bg-surface text-fg border border-border hover:bg-surface-2",
        ghost: "text-fg hover:bg-surface-2",
        outline:
          "border border-border bg-transparent text-fg hover:bg-surface",
        danger: "bg-danger text-primary-fg hover:bg-danger/90",
      },
      size: {
        md: "h-10 rounded-md px-3.5 text-sm",
        sm: "h-8 rounded-sm px-2.5 text-xs",
        lg: "h-11 rounded-md px-4 text-sm",
        icon: "size-10 rounded-md",
        toolbar: "size-11 rounded-md",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "md",
    },
  },
);

export interface ButtonProps
  extends ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  asChild?: boolean;
  unstyled?: boolean;
}

export function Button({
  className,
  variant,
  size,
  asChild = false,
  unstyled = false,
  ...props
}: ButtonProps) {
  const Comp = asChild ? Slot : "button";
  return (
    <Comp
      className={cn(
        buttonVariants({ variant, size }),
        !unstyled && "active:not-disabled:scale-[0.96]",
        className,
      )}
      {...props}
    />
  );
}

export { buttonVariants };
