import type { PointerEvent as ReactPointerEvent } from "react";
import { FileText } from "lucide-react";
import type { BoardItem, ImageItem, TextItem } from "@/lib/board-types";
import { cn } from "@/lib/utils";
import { useBoard } from "@/store/board-store";

export type ResizeHandle = "nw" | "ne" | "sw" | "se";

interface BoardItemViewProps {
  item: BoardItem;
  selected: boolean;
  zoom: number;
  editing: boolean;
  onItemPointerDown: (event: ReactPointerEvent<HTMLDivElement>, id: string) => void;
  onHandlePointerDown: (
    event: ReactPointerEvent<HTMLElement>,
    id: string,
    handle: ResizeHandle,
  ) => void;
  onStartEdit: (id: string) => void;
  onEndEdit: () => void;
}

const HANDLES: ResizeHandle[] = ["nw", "ne", "sw", "se"];

const HANDLE_CLASS: Record<ResizeHandle, string> = {
  nw: "left-0 top-0 -translate-x-1/2 -translate-y-1/2 cursor-nwse-resize",
  ne: "right-0 top-0 translate-x-1/2 -translate-y-1/2 cursor-nesw-resize",
  sw: "bottom-0 left-0 -translate-x-1/2 translate-y-1/2 cursor-nesw-resize",
  se: "bottom-0 right-0 translate-x-1/2 translate-y-1/2 cursor-nwse-resize",
};

export function BoardItemView({
  item,
  selected,
  zoom: _zoom,
  editing,
  onItemPointerDown,
  onHandlePointerDown,
  onStartEdit,
  onEndEdit,
}: BoardItemViewProps) {
  const url = useBoard((state) =>
    item.type === "image" ? state.urls[item.blobId] : undefined,
  );

  return (
    <div
      data-board-item={item.id}
      className={cn(
        "absolute origin-center",
        selected && "z-20",
      )}
      style={{
        left: item.x,
        top: item.y,
        width: item.w,
        height: item.h,
        zIndex: selected ? 10000 + item.z : item.z,
        transform: `rotate(${item.rotation}deg)`,
      }}
      onPointerDown={(event) => onItemPointerDown(event, item.id)}
      onDoubleClick={(event) => {
        if (item.type !== "text") return;
        event.stopPropagation();
        onStartEdit(item.id);
      }}
    >
      {item.type === "image" ? (
        <ImagePin item={item} url={url} />
      ) : (
        <TextPin item={item} editing={editing} onEndEdit={onEndEdit} />
      )}

      {selected ? (
        <div className="pointer-events-none absolute inset-0 rounded-[2px] ring-2 ring-primary" />
      ) : null}

      {selected
        ? HANDLES.map((handle) => (
            <button
              key={handle}
              type="button"
              aria-label={`Redimensionează ${handle}`}
              className={cn(
                "resize-handle pointer-events-auto z-10",
                HANDLE_CLASS[handle],
              )}
              onPointerDown={(event) => onHandlePointerDown(event, item.id, handle)}
            />
          ))
        : null}
    </div>
  );
}

function ImagePin({ item, url }: { item: ImageItem; url?: string }) {
  return (
    <div className="pin-card relative h-full w-full rounded-sm p-2 pb-7">
      <span className="pin-head" aria-hidden />
      <div className="relative h-full w-full overflow-hidden rounded-[2px] bg-surface-2">
        {url ? (
          <img
            src={url}
            alt={item.name}
            draggable={false}
            crossOrigin="anonymous"
            className="size-full object-cover select-none"
          />
        ) : (
          <div className="size-full animate-pulse bg-surface-2" />
        )}
      </div>
      {item.source === "pdf" ? (
        <div className="absolute right-2 bottom-1.5 left-2 flex items-center gap-1 text-xs tracking-wide text-muted">
          <FileText className="size-3" />
          <span className="truncate">
            {item.name}
            {item.page ? ` · ${item.page}` : ""}
          </span>
        </div>
      ) : null}
    </div>
  );
}

function TextPin({
  item,
  editing,
  onEndEdit,
}: {
  item: TextItem;
  editing: boolean;
  onEndEdit: () => void;
}) {
  const updateText = useBoard((state) => state.updateText);
  const toneClass =
    item.tone === "ink"
      ? "note-ink"
      : item.tone === "cream"
        ? "note-cream"
        : "note-plain";
  const isDisplay = item.variant === "display";

  return (
    <div
      className={cn(
        "relative h-full w-full overflow-hidden",
        toneClass,
        isDisplay ? "rounded-none px-1 py-1" : "rounded-md px-4 py-4",
      )}
    >
      {item.tone !== "plain" ? <span className="pin-head" aria-hidden /> : null}
      {editing ? (
        <textarea
          autoFocus
          defaultValue={item.content}
          onPointerDown={(event) => event.stopPropagation()}
          onBlur={(event) => {
            updateText(item.id, event.currentTarget.value);
            onEndEdit();
          }}
          onKeyDown={(event) => {
            if (event.key === "Escape") {
              event.currentTarget.blur();
            }
            event.stopPropagation();
          }}
          className={cn(
            "h-full w-full resize-none bg-transparent outline-none",
            isDisplay ? "font-display font-medium tracking-tight" : "leading-normal",
            item.align === "center" && "text-center",
          )}
          style={{ fontSize: item.fontSize }}
        />
      ) : (
        <p
          className={cn(
            "h-full w-full overflow-hidden whitespace-pre-wrap break-words",
            isDisplay
              ? "font-display font-medium tracking-tight leading-tight"
              : "leading-normal",
            item.align === "center" && "text-center",
          )}
          style={{ fontSize: item.fontSize }}
        >
          {item.content}
        </p>
      )}
    </div>
  );
}
