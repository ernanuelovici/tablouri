import { useState } from "react";
import { Check, Copy, HelpCircle, Link2, Loader2, MoreHorizontal } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { publishBoard, shareUrlForId } from "@/lib/share-client";
import { useBoard } from "@/store/board-store";

interface BoardHeaderProps {
  onHelp: () => void;
  onFit: () => void;
}

export function BoardHeader({ onHelp, onFit }: BoardHeaderProps) {
  const title = useBoard((state) => state.title);
  const setTitle = useBoard((state) => state.setTitle);
  const clearBoard = useBoard((state) => state.clearBoard);
  const loadDemo = useBoard((state) => state.loadDemo);
  const undo = useBoard((state) => state.undo);
  const redo = useBoard((state) => state.redo);
  const canUndo = useBoard((state) => state.past.length > 0);
  const canRedo = useBoard((state) => state.future.length > 0);
  const shareId = useBoard((state) => state.shareId);
  const setShareId = useBoard((state) => state.setShareId);
  const items = useBoard((state) => state.items);
  const pan = useBoard((state) => state.pan);
  const zoom = useBoard((state) => state.zoom);

  const [sharing, setSharing] = useState(false);
  const [shareOpen, setShareOpen] = useState(false);
  const [shareLink, setShareLink] = useState("");
  const [copied, setCopied] = useState(false);

  async function onShare() {
    if (shareId) {
      setShareLink(shareUrlForId(shareId));
      setShareOpen(true);
      return;
    }
    setSharing(true);
    try {
      const { id, url } = await publishBoard({ title, items, pan, zoom });
      setShareId(id);
      const next = new URL(window.location.href);
      next.searchParams.set("s", id);
      window.history.replaceState({}, "", next.toString());
      setShareLink(url);
      setShareOpen(true);
      toast.success("Link de partajare creat");
    } catch (err) {
      const message =
        err instanceof Error ? err.message : "Nu am putut crea link-ul";
      toast.error(message);
    } finally {
      setSharing(false);
    }
  }

  async function onCopy() {
    try {
      await navigator.clipboard.writeText(shareLink);
      setCopied(true);
      toast.success("Link copiat");
      window.setTimeout(() => setCopied(false), 1500);
    } catch {
      toast.error("Nu am putut copia link-ul");
    }
  }

  return (
    <>
      <header className="pointer-events-none absolute inset-x-0 top-0 z-30 flex items-start justify-between gap-3 p-3 pt-[max(0.75rem,env(safe-area-inset-top))]">
        <div className="pointer-events-auto flex min-w-0 items-center gap-3 rounded-lg border border-border bg-card/95 py-2 pr-3 pl-2.5 shadow-pin backdrop-blur-sm">
          <div
            className="flex size-9 shrink-0 items-center justify-center rounded-sm bg-primary font-display text-lg font-medium text-primary-fg"
            aria-hidden
          >
            T
          </div>
          <div className="min-w-0">
            <p className="text-xs font-medium tracking-wide text-muted uppercase">
              Tablou
              {shareId ? (
                <span className="ml-1.5 rounded bg-primary/10 px-1.5 py-0.5 text-[10px] font-semibold tracking-normal text-primary normal-case">
                  partajat
                </span>
              ) : null}
            </p>
            <input
              value={title}
              onChange={(event) => setTitle(event.target.value)}
              aria-label="Titlul tabloului"
              className="w-full min-w-32 truncate bg-transparent font-display text-base font-medium tracking-tight outline-none md:min-w-48"
            />
          </div>
        </div>

        <div className="pointer-events-auto flex items-center gap-1.5 rounded-lg border border-border bg-card/95 p-1.5 shadow-pin backdrop-blur-sm">
          <Button
            type="button"
            variant="ghost"
            size="icon"
            aria-label="Partajează link"
            disabled={sharing}
            onClick={() => void onShare()}
          >
            {sharing ? <Loader2 className="animate-spin" /> : <Link2 />}
          </Button>
          <Button
            type="button"
            variant="ghost"
            size="icon"
            aria-label="Ajutor"
            onClick={onHelp}
          >
            <HelpCircle />
          </Button>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button type="button" variant="ghost" size="icon" aria-label="Mai multe">
                <MoreHorizontal />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onSelect={() => void onShare()}>
                Partajează link
              </DropdownMenuItem>
              <DropdownMenuItem onSelect={onFit}>Potrivește în ecran</DropdownMenuItem>
              <DropdownMenuItem onSelect={() => undo()} disabled={!canUndo}>
                Anulează
              </DropdownMenuItem>
              <DropdownMenuItem onSelect={() => redo()} disabled={!canRedo}>
                Refă
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onSelect={() => void loadDemo()}>
                Încarcă exemplul
              </DropdownMenuItem>
              <DropdownMenuItem onSelect={clearBoard}>Golește pânza</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </header>

      <Dialog open={shareOpen} onOpenChange={setShareOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Link de partajare</DialogTitle>
            <DialogDescription>
              Oricine are acest link poate vedea și edita tabloul. Nu e nevoie de
              cont. Modificările se sincronizează automat.
            </DialogDescription>
          </DialogHeader>
          <div className="mt-3 flex gap-2">
            <input
              readOnly
              value={shareLink}
              className="min-w-0 flex-1 rounded-md border border-border bg-surface-2 px-3 py-2 text-sm outline-none"
              onFocus={(e) => e.currentTarget.select()}
            />
            <Button type="button" onClick={() => void onCopy()}>
              {copied ? <Check className="size-4" /> : <Copy className="size-4" />}
              <span className="ml-1.5">{copied ? "Copiat" : "Copiază"}</span>
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
