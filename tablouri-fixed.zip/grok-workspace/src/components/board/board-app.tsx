import { useEffect, useRef, useState } from "react";
import { toast, Toaster } from "sonner";
import { BoardCanvas } from "@/components/board/canvas";
import { BoardHeader } from "@/components/board/header";
import { HelpDialog } from "@/components/board/help-dialog";
import { BoardToolbar } from "@/components/board/toolbar";
import { TooltipProvider } from "@/components/ui/tooltip";
import { screenToWorld, zoomToward } from "@/lib/geometry";
import { MAX_PDF_PAGES } from "@/lib/board-types";
import { useBoard } from "@/store/board-store";

export function BoardApp() {
  const viewportRef = useRef<HTMLDivElement | null>(null);
  const [helpOpen, setHelpOpen] = useState(false);
  const [dropping, setDropping] = useState(false);
  const dragDepth = useRef(0);

  const ready = useBoard((state) => state.ready);
  const hydrate = useBoard((state) => state.hydrate);
  const needsFit = useBoard((state) => state.needsFit);
  const fitView = useBoard((state) => state.fitView);
  const markFitted = useBoard((state) => state.markFitted);
  const ingestFiles = useBoard((state) => state.ingestFiles);
  const addTextAt = useBoard((state) => state.addTextAt);
  const undo = useBoard((state) => state.undo);
  const redo = useBoard((state) => state.redo);
  const removeSelected = useBoard((state) => state.removeSelected);
  const duplicateSelected = useBoard((state) => state.duplicateSelected);
  const select = useBoard((state) => state.select);

  useEffect(() => {
    void hydrate();
  }, [hydrate]);

  useEffect(() => {
    const node = viewportRef.current;
    if (!node) return;

    const fit = () => {
      if (node.clientWidth < 40 || node.clientHeight < 40) return;
      const state = useBoard.getState();
      if (!state.ready || state.items.length === 0) return;
      state.fitView({ w: node.clientWidth, h: node.clientHeight });
      state.markFitted();
    };

    if (ready && (needsFit || node.clientWidth > 0)) fit();

    let lastW = node.clientWidth;
    let lastH = node.clientHeight;
    let timer = 0;
    const observer = new ResizeObserver(() => {
      const w = node.clientWidth;
      const h = node.clientHeight;
      if (Math.abs(w - lastW) < 80 && Math.abs(h - lastH) < 80) return;
      lastW = w;
      lastH = h;
      window.clearTimeout(timer);
      timer = window.setTimeout(fit, 50);
    });
    observer.observe(node);
    return () => {
      observer.disconnect();
      window.clearTimeout(timer);
    };
  }, [ready, needsFit]);

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      const target = event.target as HTMLElement | null;
      const typing =
        target &&
        (target.tagName === "INPUT" ||
          target.tagName === "TEXTAREA" ||
          target.isContentEditable);
      const meta = event.metaKey || event.ctrlKey;

      if (event.code === "Space" && !typing) {
        event.preventDefault();
      }
      if (event.key === "?" && !typing) {
        event.preventDefault();
        setHelpOpen(true);
        return;
      }
      if (typing) return;

      if (meta && event.key.toLowerCase() === "z") {
        event.preventDefault();
        if (event.shiftKey) redo();
        else undo();
        return;
      }
      if (meta && event.key.toLowerCase() === "d") {
        event.preventDefault();
        duplicateSelected();
        return;
      }
      if (meta && event.key.toLowerCase() === "a") {
        event.preventDefault();
        select(useBoard.getState().items.map((item) => item.id));
        return;
      }
      if (event.key === "Delete" || event.key === "Backspace") {
        event.preventDefault();
        removeSelected();
      }
    };

    const onPaste = (event: ClipboardEvent) => {
      const target = event.target as HTMLElement | null;
      if (
        target &&
        (target.tagName === "INPUT" ||
          target.tagName === "TEXTAREA" ||
          target.isContentEditable)
      ) {
        return;
      }
      const items = event.clipboardData?.files;
      if (items && items.length) {
        event.preventDefault();
        void handleFiles([...items]);
      }
    };

    window.addEventListener("keydown", onKeyDown);
    window.addEventListener("paste", onPaste);
    return () => {
      window.removeEventListener("keydown", onKeyDown);
      window.removeEventListener("paste", onPaste);
    };
  }, [undo, redo, removeSelected, duplicateSelected, select]);

  function centerWorld() {
    const node = viewportRef.current;
    const state = useBoard.getState();
    if (!node) return { x: 120, y: 120 };
    const rect = node.getBoundingClientRect();
    return screenToWorld(
      rect.left + rect.width / 2,
      rect.top + rect.height / 2 - 40,
      rect,
      state.pan,
      state.zoom,
    );
  }

  async function handleFiles(files: File[], client?: { x: number; y: number }) {
    const node = viewportRef.current;
    const state = useBoard.getState();
    const at = client && node
      ? screenToWorld(
          client.x,
          client.y,
          node.getBoundingClientRect(),
          state.pan,
          state.zoom,
        )
      : centerWorld();
    const result = await ingestFiles(files, at);
    if (result.added) {
      toast.success(
        result.added === 1
          ? "Element adăugat pe pânză"
          : `${result.added} elemente adăugate`,
      );
    }
    if (result.truncatedPdf) {
      toast.message(`Am importat primele ${MAX_PDF_PAGES} pagini din PDF.`);
    }
    if (result.skipped) {
      toast.error(
        result.skipped === 1
          ? "Un fișier nu a putut fi adăugat. Folosește JPG, PNG sau PDF."
          : `${result.skipped} fișiere au fost omise.`,
      );
    }
  }

  function onFit() {
    const node = viewportRef.current;
    if (!node) return;
    fitView({ w: node.clientWidth, h: node.clientHeight });
  }

  function onZoomBy(factor: number) {
    const node = viewportRef.current;
    const state = useBoard.getState();
    if (!node) return;
    const rect = node.getBoundingClientRect();
    const next = zoomToward(
      rect.left + rect.width / 2,
      rect.top + rect.height / 2,
      rect,
      state.pan,
      state.zoom,
      state.zoom * factor,
    );
    state.setView(next.pan, next.zoom);
  }

  return (
    <TooltipProvider>
      <div
        className="relative h-dvh overflow-hidden bg-bg text-fg"
        onDragEnter={(event) => {
          event.preventDefault();
          dragDepth.current += 1;
          setDropping(true);
        }}
        onDragLeave={(event) => {
          event.preventDefault();
          dragDepth.current = Math.max(0, dragDepth.current - 1);
          if (dragDepth.current === 0) setDropping(false);
        }}
        onDragOver={(event) => event.preventDefault()}
        onDrop={(event) => {
          event.preventDefault();
          dragDepth.current = 0;
          setDropping(false);
          const files = [...event.dataTransfer.files];
          if (files.length) void handleFiles(files, { x: event.clientX, y: event.clientY });
        }}
      >
        <BoardCanvas
          dropping={dropping}
          onDropFiles={(files, x, y) => void handleFiles(files, { x, y })}
          viewportRef={viewportRef}
        />

        <BoardHeader onHelp={() => setHelpOpen(true)} onFit={onFit} />
        <BoardToolbar
          onAddFiles={(files) => void handleFiles(files)}
          onAddText={() => addTextAt(centerWorld().x, centerWorld().y)}
          onZoomBy={onZoomBy}
          onFit={onFit}
        />

        <HelpDialog open={helpOpen} onOpenChange={setHelpOpen} />
        <Toaster
          theme="light"
          position="top-center"
          offset={88}
          toastOptions={{
            className: "font-sans",
            style: {
              background: "var(--color-card)",
              color: "var(--color-fg)",
              border: "1px solid var(--color-border)",
            },
          }}
        />
      </div>
    </TooltipProvider>
  );
}
