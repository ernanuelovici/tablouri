import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

const ROWS = [
  ["Trage pe pânză", "Deplasează vederea"],
  ["Roata mouse-ului", "Zoom spre cursor"],
  ["Trage un element", "Mută pe pânză"],
  ["Colțurile selecției", "Redimensionează"],
  ["Dublu-click pe notă", "Editează textul"],
  ["Delete / Backspace", "Șterge selecția"],
  ["Ctrl/Cmd + Z", "Anulează"],
  ["Ctrl/Cmd + D", "Duplică"],
];

export function HelpDialog({
  open,
  onOpenChange,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Cum lucrezi pe Tablou</DialogTitle>
          <DialogDescription>
            Inserează imagini JPG, documente PDF și casete text, apoi aranjează-le
            liber — ca pe un panou de inspirație.
          </DialogDescription>
        </DialogHeader>
        <ul className="space-y-2">
          {ROWS.map(([action, result]) => (
            <li
              key={action}
              className="flex items-baseline justify-between gap-4 border-b border-border py-2 last:border-0"
            >
              <span className="text-sm font-medium">{action}</span>
              <span className="text-right text-sm text-muted">{result}</span>
            </li>
          ))}
        </ul>
      </DialogContent>
    </Dialog>
  );
}
