import {
  Copy,
  FileText,
  ImagePlus,
  LayoutGrid,
  RotateCw,
  Trash2,
  Type,
  ZoomIn,
  ZoomOut,
} from "lucide-react";
import { useRef, type ReactNode } from "react";
import { Button } from "@/components/ui/button";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { useBoard } from "@/store/board-store";

interface BoardToolbarProps {
  onAddFiles: (files: File[]) => void;
  onAddText: () => void;
  onZoomBy: (factor: number) => void;
  onFit: () => void;
}

function Tip({
  label,
  children,
}: {
  label: string;
  children: ReactNode;
}) {
  return (
    <Tooltip>
      <TooltipTrigger asChild>{children}</TooltipTrigger>
      <TooltipContent>{label}</TooltipContent>
    </Tooltip>
  );
}

export function BoardToolbar({
  onAddFiles,
  onAddText,
  onZoomBy,
  onFit,
}: BoardToolbarProps) {
  const imageInput = useRef<HTMLInputElement>(null);
  const pdfInput = useRef<HTMLInputElement>(null);
  const selectedCount = useBoard((state) => state.selectedIds.length);
  const zoom = useBoard((state) => state.zoom);
  const duplicateSelected = useBoard((state) => state.duplicateSelected);
  const bringToFront = useBoard((state) => state.bringToFront);
  const rotateSelected = useBoard((state) => state.rotateSelected);
  const removeSelected = useBoard((state) => state.removeSelected);
  const packGrid = useBoard((state) => state.packGrid);

  return (
    <div className="pointer-events-none absolute inset-x-0 bottom-0 z-30 flex justify-center p-3 pb-[max(0.75rem,env(safe-area-inset-bottom))]">
      <div className="pointer-events-auto flex max-w-full items-center gap-1 overflow-x-auto rounded-xl border border-border bg-card/95 p-1.5 shadow-pin backdrop-blur-sm">
        <input
          ref={imageInput}
          type="file"
          accept="image/jpeg,image/jpg,image/png,image/webp,image/gif"
          multiple
          className="hidden"
          onChange={(event) => {
            const files = [...(event.target.files ?? [])];
            event.target.value = "";
            if (files.length) onAddFiles(files);
          }}
        />
        <input
          ref={pdfInput}
          type="file"
          accept="application/pdf,.pdf"
          multiple
          className="hidden"
          onChange={(event) => {
            const files = [...(event.target.files ?? [])];
            event.target.value = "";
            if (files.length) onAddFiles(files);
          }}
        />

        <Tip label="Adaugă imagine">
          <Button
            type="button"
            variant="ghost"
            size="toolbar"
            aria-label="Adaugă imagine"
            onClick={() => imageInput.current?.click()}
          >
            <ImagePlus />
          </Button>
        </Tip>
        <Tip label="Adaugă PDF">
          <Button
            type="button"
            variant="ghost"
            size="toolbar"
            aria-label="Adaugă PDF"
            onClick={() => pdfInput.current?.click()}
          >
            <FileText />
          </Button>
        </Tip>
        <Tip label="Adaugă notă">
          <Button
            type="button"
            variant="ghost"
            size="toolbar"
            aria-label="Adaugă notă"
            onClick={onAddText}
          >
            <Type />
          </Button>
        </Tip>

        <div className="mx-1 hidden h-6 w-px bg-border sm:block" />

        {selectedCount > 0 ? (
          <>
            <Tip label="Duplică">
              <Button
                type="button"
                variant="ghost"
                size="toolbar"
                aria-label="Duplică"
                onClick={duplicateSelected}
              >
                <Copy />
              </Button>
            </Tip>
            <Tip label="Rotește">
              <Button
                type="button"
                variant="ghost"
                size="toolbar"
                aria-label="Rotește"
                onClick={() => rotateSelected(12)}
              >
                <RotateCw />
              </Button>
            </Tip>
            <Tip label="Șterge">
              <Button
                type="button"
                variant="ghost"
                size="toolbar"
                aria-label="Șterge"
                onClick={removeSelected}
              >
                <Trash2 />
              </Button>
            </Tip>
            <button
              type="button"
              className="hidden h-11 rounded-md px-2 text-xs font-medium text-muted hover:bg-surface-2 hover:text-fg sm:inline"
              onClick={bringToFront}
            >
              În față
            </button>
          </>
        ) : (
          <Tip label="Aranjează în grilă">
            <Button
              type="button"
              variant="ghost"
              size="toolbar"
              aria-label="Aranjează în grilă"
              onClick={packGrid}
            >
              <LayoutGrid />
            </Button>
          </Tip>
        )}

        <div className="mx-1 hidden h-6 w-px bg-border sm:block" />

        <Tip label="Micșorează">
          <Button
            type="button"
            variant="ghost"
            size="toolbar"
            aria-label="Micșorează"
            onClick={() => onZoomBy(0.9)}
          >
            <ZoomOut />
          </Button>
        </Tip>
        <button
          type="button"
          onClick={onFit}
          className="hidden h-11 min-w-14 rounded-md px-2 font-medium tabular-nums text-muted hover:bg-surface-2 hover:text-fg sm:inline"
          aria-label="Potrivește în ecran"
        >
          {Math.round(zoom * 100)}%
        </button>
        <Tip label="Mărește">
          <Button
            type="button"
            variant="ghost"
            size="toolbar"
            aria-label="Mărește"
            onClick={() => onZoomBy(1.1)}
          >
            <ZoomIn />
          </Button>
        </Tip>
      </div>
    </div>
  );
}
