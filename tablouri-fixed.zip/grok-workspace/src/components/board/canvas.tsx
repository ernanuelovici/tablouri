import {
  useCallback,
  useEffect,
  useRef,
  useState,
  type DragEvent as ReactDragEvent,
  type PointerEvent as ReactPointerEvent,
  type RefObject,
} from "react";
import { ImagePlus } from "lucide-react";
import { BoardItemView, type ResizeHandle } from "@/components/board/board-item";
import type { BoardItem } from "@/lib/board-types";
import { clampZoom, screenToWorld, zoomToward } from "@/lib/geometry";
import { cn } from "@/lib/utils";
import { useBoard } from "@/store/board-store";

type Gesture =
  | {
      kind: "pan";
      pointerId: number;
      sx: number;
      sy: number;
      panX: number;
      panY: number;
    }
  | {
      kind: "pinch";
      startDist: number;
      startZoom: number;
      /** World-space point under the pinch midpoint at gesture start */
      worldAnchor: { x: number; y: number };
    }
  | {
      kind: "move";
      pointerId: number;
      sx: number;
      sy: number;
      origins: { id: string; x: number; y: number }[];
    }
  | {
      kind: "resize";
      pointerId: number;
      sx: number;
      sy: number;
      id: string;
      handle: ResizeHandle;
      orig: { x: number; y: number; w: number; h: number };
      lockAspect: boolean;
    };

function applyResize(
  handle: ResizeHandle,
  dx: number,
  dy: number,
  orig: { x: number; y: number; w: number; h: number },
  lockAspect: boolean,
): { x: number; y: number; w: number; h: number } {
  const ratio = orig.w / Math.max(1, orig.h);
  let { x, y, w, h } = orig;

  if (lockAspect) {
    if (handle === "se" || handle === "ne") {
      w = orig.w + dx;
      h = w / ratio;
      if (handle === "ne") y = orig.y + orig.h - h;
    } else {
      w = orig.w - dx;
      h = w / ratio;
      x = orig.x + orig.w - w;
      if (handle === "nw") y = orig.y + orig.h - h;
    }
  } else if (handle === "se") {
    w = orig.w + dx;
    h = orig.h + dy;
  } else if (handle === "sw") {
    w = orig.w - dx;
    h = orig.h + dy;
    x = orig.x + dx;
  } else if (handle === "ne") {
    w = orig.w + dx;
    h = orig.h - dy;
    y = orig.y + dy;
  } else {
    w = orig.w - dx;
    h = orig.h - dy;
    x = orig.x + dx;
    y = orig.y + dy;
  }

  const minW = 80;
  const minH = 64;
  if (w < minW) {
    if (handle === "nw" || handle === "sw") x = orig.x + orig.w - minW;
    w = minW;
    if (lockAspect) {
      h = w / ratio;
      if (handle === "nw" || handle === "ne") y = orig.y + orig.h - h;
    }
  }
  if (h < minH) {
    if (handle === "nw" || handle === "ne") y = orig.y + orig.h - minH;
    h = minH;
    if (lockAspect) {
      w = h * ratio;
      if (handle === "nw" || handle === "sw") x = orig.x + orig.w - w;
    }
  }

  return { x, y, w, h };
}

interface BoardCanvasProps {
  dropping: boolean;
  onDropFiles: (files: File[], clientX: number, clientY: number) => void;
  viewportRef: RefObject<HTMLDivElement | null>;
}

export function BoardCanvas({ dropping, onDropFiles, viewportRef }: BoardCanvasProps) {
  const gesture = useRef<Gesture | null>(null);
  const pointers = useRef(new Map<number, { x: number; y: number }>());
  const spaceHeld = useRef(false);
  const [editingId, setEditingId] = useState<string | null>(null);

  const items = useBoard((state) => state.items);
  const ready = useBoard((state) => state.ready);
  const selectedIds = useBoard((state) => state.selectedIds);
  const pan = useBoard((state) => state.pan);
  const zoom = useBoard((state) => state.zoom);
  const select = useBoard((state) => state.select);
  const clearSelection = useBoard((state) => state.clearSelection);
  const setView = useBoard((state) => state.setView);
  const pushHistory = useBoard((state) => state.pushHistory);
  const placeItems = useBoard((state) => state.placeItems);
  const resizeItem = useBoard((state) => state.resizeItem);

  const bounds = useCallback(() => {
    const el = viewportRef.current;
    if (!el) return new DOMRect();
    return el.getBoundingClientRect();
  }, [viewportRef]);

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.code === "Space") spaceHeld.current = true;
    };
    const onKeyUp = (event: KeyboardEvent) => {
      if (event.code === "Space") spaceHeld.current = false;
    };
    window.addEventListener("keydown", onKeyDown);
    window.addEventListener("keyup", onKeyUp);
    window.addEventListener("blur", () => {
      spaceHeld.current = false;
    });
    return () => {
      window.removeEventListener("keydown", onKeyDown);
      window.removeEventListener("keyup", onKeyUp);
    };
  }, []);

  useEffect(() => {
    const node = viewportRef.current;
    if (!node) return;
    const onWheel = (event: WheelEvent) => {
      event.preventDefault();
      const state = useBoard.getState();
      const factor = event.deltaY > 0 ? 0.92 : 1.08;
      const next = zoomToward(
        event.clientX,
        event.clientY,
        node.getBoundingClientRect(),
        state.pan,
        state.zoom,
        state.zoom * factor,
      );
      state.setView(next.pan, next.zoom);
    };
    node.addEventListener("wheel", onWheel, { passive: false });
    return () => node.removeEventListener("wheel", onWheel);
  }, [viewportRef]);

  const endGesture = useCallback(() => {
    gesture.current = null;
  }, []);

  const beginPinch = useCallback(() => {
    const pts = [...pointers.current.values()];
    if (pts.length < 2) return;
    const a = pts[0]!;
    const b = pts[1]!;
    const dist = Math.hypot(a.x - b.x, a.y - b.y);
    if (dist < 1) return;
    const midX = (a.x + b.x) / 2;
    const midY = (a.y + b.y) / 2;
    const state = useBoard.getState();
    const rect = bounds();
    gesture.current = {
      kind: "pinch",
      startDist: dist,
      startZoom: state.zoom,
      worldAnchor: screenToWorld(midX, midY, rect, state.pan, state.zoom),
    };
  }, [bounds]);

  // Global move/up so gestures keep working even when pointer capture
  // is held by an item (or when the second finger lands outside the viewport).
  useEffect(() => {
    const onWindowPointerMove = (event: PointerEvent) => {
      if (pointers.current.has(event.pointerId)) {
        pointers.current.set(event.pointerId, {
          x: event.clientX,
          y: event.clientY,
        });
      }

      if (pointers.current.size >= 2 && gesture.current?.kind !== "pinch") {
        beginPinch();
      }

      if (gesture.current?.kind === "pinch" && pointers.current.size >= 2) {
        const pts = [...pointers.current.values()];
        const a = pts[0]!;
        const b = pts[1]!;
        const dist = Math.hypot(a.x - b.x, a.y - b.y);
        if (dist < 1) return;
        const midX = (a.x + b.x) / 2;
        const midY = (a.y + b.y) / 2;
        const g = gesture.current;
        const nextZoom = clampZoom(g.startZoom * (dist / g.startDist));
        const rect = bounds();
        // Keep the same world point under the current pinch midpoint
        setView(
          {
            x: midX - rect.left - g.worldAnchor.x * nextZoom,
            y: midY - rect.top - g.worldAnchor.y * nextZoom,
          },
          nextZoom,
        );
        return;
      }

      const g = gesture.current;
      if (!g) return;
      const state = useBoard.getState();
      if (g.kind === "pan") {
        setView(
          {
            x: g.panX + (event.clientX - g.sx),
            y: g.panY + (event.clientY - g.sy),
          },
          state.zoom,
        );
        return;
      }
      if (g.kind === "move") {
        if (event.pointerId !== g.pointerId) return;
        const dx = (event.clientX - g.sx) / state.zoom;
        const dy = (event.clientY - g.sy) / state.zoom;
        placeItems(
          g.origins.map((origin) => ({
            id: origin.id,
            x: origin.x + dx,
            y: origin.y + dy,
          })),
        );
        return;
      }
      if (g.kind === "resize") {
        if (event.pointerId !== g.pointerId) return;
        const dx = (event.clientX - g.sx) / state.zoom;
        const dy = (event.clientY - g.sy) / state.zoom;
        resizeItem(g.id, applyResize(g.handle, dx, dy, g.orig, g.lockAspect));
      }
    };

    const onWindowPointerUp = (event: PointerEvent) => {
      pointers.current.delete(event.pointerId);

      if (gesture.current?.kind === "pinch") {
        if (pointers.current.size >= 2) {
          beginPinch();
        } else if (pointers.current.size === 1) {
          const remaining = [...pointers.current.entries()][0]!;
          const state = useBoard.getState();
          gesture.current = {
            kind: "pan",
            pointerId: remaining[0],
            sx: remaining[1].x,
            sy: remaining[1].y,
            panX: state.pan.x,
            panY: state.pan.y,
          };
        } else {
          endGesture();
        }
        return;
      }

      if (gesture.current && "pointerId" in gesture.current) {
        if (gesture.current.pointerId === event.pointerId) endGesture();
      }
      if (pointers.current.size === 0) endGesture();
    };

    window.addEventListener("pointermove", onWindowPointerMove);
    window.addEventListener("pointerup", onWindowPointerUp);
    window.addEventListener("pointercancel", onWindowPointerUp);
    return () => {
      window.removeEventListener("pointermove", onWindowPointerMove);
      window.removeEventListener("pointerup", onWindowPointerUp);
      window.removeEventListener("pointercancel", onWindowPointerUp);
    };
  }, [beginPinch, bounds, endGesture, placeItems, resizeItem, setView]);

  const onItemPointerDown = (
    event: ReactPointerEvent<HTMLDivElement>,
    id: string,
  ) => {
    if (event.button !== 0) return;
    if (editingId) return;
    event.stopPropagation();

    // Always track pointers so a second finger can start a pinch
    pointers.current.set(event.pointerId, {
      x: event.clientX,
      y: event.clientY,
    });

    if (pointers.current.size >= 2) {
      beginPinch();
      return;
    }

    const state = useBoard.getState();
    const already = state.selectedIds.includes(id);
    const nextIds = event.shiftKey
      ? already
        ? state.selectedIds.filter((value) => value !== id)
        : [...state.selectedIds, id]
      : already
        ? state.selectedIds
        : [id];
    state.select(nextIds);
    const movingIds = nextIds.length ? nextIds : [id];
    const origins = state.items
      .filter((item) => movingIds.includes(item.id))
      .map((item) => ({ id: item.id, x: item.x, y: item.y }));
    state.pushHistory();
    gesture.current = {
      kind: "move",
      pointerId: event.pointerId,
      sx: event.clientX,
      sy: event.clientY,
      origins,
    };
    event.currentTarget.setPointerCapture(event.pointerId);
  };

  const onHandlePointerDown = (
    event: ReactPointerEvent<HTMLElement>,
    id: string,
    handle: ResizeHandle,
  ) => {
    if (event.button !== 0) return;
    event.stopPropagation();
    const item = useBoard.getState().items.find((entry) => entry.id === id);
    if (!item) return;
    pushHistory();
    select([id]);
    gesture.current = {
      kind: "resize",
      pointerId: event.pointerId,
      sx: event.clientX,
      sy: event.clientY,
      id,
      handle,
      orig: { x: item.x, y: item.y, w: item.w, h: item.h },
      lockAspect: item.type === "image" && !event.shiftKey,
    };
    (event.currentTarget as HTMLElement).setPointerCapture(event.pointerId);
  };

  const onViewportPointerDown = (event: ReactPointerEvent<HTMLDivElement>) => {
    if (event.button === 2) return;
    const target = event.target as HTMLElement;
    if (target.closest("[data-board-item]")) return;
    setEditingId(null);
    if (!event.shiftKey) clearSelection();
    pointers.current.set(event.pointerId, {
      x: event.clientX,
      y: event.clientY,
    });
    if (pointers.current.size >= 2) {
      beginPinch();
      return;
    }
    gesture.current = {
      kind: "pan",
      pointerId: event.pointerId,
      sx: event.clientX,
      sy: event.clientY,
      panX: pan.x,
      panY: pan.y,
    };
    event.currentTarget.setPointerCapture(event.pointerId);
  };

  const onDragOver = (event: ReactDragEvent<HTMLDivElement>) => {
    event.preventDefault();
  };

  const onDrop = (event: ReactDragEvent<HTMLDivElement>) => {
    event.preventDefault();
    const files = [...event.dataTransfer.files];
    if (files.length) onDropFiles(files, event.clientX, event.clientY);
  };

  const sorted = [...items].sort((a, b) => a.z - b.z);
  const empty = ready && items.length === 0;

  return (
    <div
      ref={viewportRef}
      className={cn(
        "board-viewport relative h-full w-full overflow-hidden",
        spaceHeld.current ? "cursor-grab" : "cursor-default",
      )}
      style={{
        backgroundSize: `${28 * zoom}px ${28 * zoom}px`,
        backgroundPosition: `${pan.x}px ${pan.y}px`,
      }}
      onPointerDown={onViewportPointerDown}
      onDragOver={onDragOver}
      onDrop={onDrop}
    >
      <div
        className="absolute top-0 left-0 will-change-transform"
        style={{
          transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom})`,
          transformOrigin: "0 0",
        }}
      >
        {sorted.map((item: BoardItem) => (
          <BoardItemView
            key={item.id}
            item={item}
            selected={selectedIds.includes(item.id)}
            zoom={zoom}
            editing={editingId === item.id}
            onItemPointerDown={onItemPointerDown}
            onHandlePointerDown={onHandlePointerDown}
            onStartEdit={(id) => {
              pushHistory();
              select([id]);
              setEditingId(id);
            }}
            onEndEdit={() => setEditingId(null)}
          />
        ))}
      </div>

      {empty ? (
        <div className="pointer-events-none absolute inset-0 flex items-center justify-center p-6">
          <div className="max-w-sm rounded-xl border border-border bg-card/90 px-6 py-8 text-center shadow-pin">
            <div className="mx-auto mb-4 flex size-12 items-center justify-center rounded-lg bg-surface-2 text-primary">
              <ImagePlus className="size-5" />
            </div>
            <p className="font-display text-xl font-medium tracking-tight">
              Pânza e goală
            </p>
            <p className="mt-2 text-sm text-muted">
              Adaugă o imagine, un PDF sau o notă — apoi aranjează-le liber.
            </p>
          </div>
        </div>
      ) : null}

      {dropping ? (
        <div className="pointer-events-none absolute inset-3 flex items-center justify-center rounded-xl border-2 border-dashed border-primary bg-primary/10">
          <p className="font-display text-lg text-primary">
            Eliberează imaginile sau PDF-urile
          </p>
        </div>
      ) : null}
    </div>
  );
}

export function worldPointFromClient(
  clientX: number,
  clientY: number,
  viewport: HTMLElement | null,
): { x: number; y: number } {
  const state = useBoard.getState();
  if (!viewport) return { x: 80, y: 80 };
  return screenToWorld(
    clientX,
    clientY,
    viewport.getBoundingClientRect(),
    state.pan,
    state.zoom,
  );
}
