//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-HFrs3Dux.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-BBRtc3NR.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BBRtc3NR.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-B4mpG_FR.js"]
	}
} });
//#endregion
export { tsrStartManifest };
