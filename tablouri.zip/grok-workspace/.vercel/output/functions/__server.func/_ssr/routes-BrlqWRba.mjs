import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { r as Slot, s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { c as LayoutGrid, d as Ellipsis, f as Copy, i as Type, l as ImagePlus, n as ZoomOut, o as Trash2, p as CircleHelp, r as X, s as RotateCw, t as ZoomIn, u as FileText } from "../_libs/lucide-react.mjs";
import { n as toast, t as Toaster } from "../_libs/sonner.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { t as create } from "../_libs/zustand.mjs";
import { a as DialogOverlay$1, i as DialogDescription$1, n as DialogClose, o as DialogPortal, r as DialogContent$1, s as DialogTitle$1, t as Dialog$1 } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { a as Separator2, i as Root2, n as Item2, o as Trigger, r as Portal2, t as Content2 } from "../_libs/@radix-ui/react-dropdown-menu+[...].mjs";
import { a as Trigger$1, i as Root3, n as Portal, r as Provider, t as Content2$1 } from "../_libs/@radix-ui/react-tooltip+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BrlqWRba.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var DB_NAME = "tablou-v1";
var DB_VERSION = 1;
function requestToPromise(request) {
	return new Promise((resolve, reject) => {
		request.onsuccess = () => resolve(request.result);
		request.onerror = () => reject(request.error);
	});
}
function txDone(tx) {
	return new Promise((resolve, reject) => {
		tx.oncomplete = () => resolve();
		tx.onerror = () => reject(tx.error);
		tx.onabort = () => reject(tx.error ?? /* @__PURE__ */ new Error("IndexedDB aborted"));
	});
}
var dbPromise = null;
function openDb() {
	if (!dbPromise) dbPromise = new Promise((resolve, reject) => {
		const request = indexedDB.open(DB_NAME, DB_VERSION);
		request.onupgradeneeded = () => {
			const db = request.result;
			if (!db.objectStoreNames.contains("blobs")) db.createObjectStore("blobs");
			if (!db.objectStoreNames.contains("kv")) db.createObjectStore("kv");
		};
		request.onsuccess = () => resolve(request.result);
		request.onerror = () => reject(request.error);
	});
	return dbPromise;
}
async function kvGet(key) {
	return await requestToPromise((await openDb()).transaction("kv").objectStore("kv").get(key));
}
async function kvSet(key, value) {
	const tx = (await openDb()).transaction("kv", "readwrite");
	tx.objectStore("kv").put(value, key);
	await txDone(tx);
}
async function blobPut(id, blob) {
	const tx = (await openDb()).transaction("blobs", "readwrite");
	tx.objectStore("blobs").put(blob, id);
	await txDone(tx);
}
async function blobGet(id) {
	return await requestToPromise((await openDb()).transaction("blobs").objectStore("blobs").get(id));
}
var ZOOM_MIN = .2;
function isPdfFile(file) {
	return file.type === "application/pdf" || file.name.toLowerCase().endsWith(".pdf");
}
function isImageFile(file) {
	if (file.type.startsWith("image/")) return true;
	return /\.(jpe?g|png|webp|gif)$/i.test(file.name);
}
function fitPinSize(width, height) {
	const scale = Math.min(280 / width, 380 / height);
	return {
		w: Math.max(80, Math.round(width * scale)),
		h: Math.max(80, Math.round(height * scale))
	};
}
async function fileToJpegBlob(file, maxEdge = 1920, quality = .86) {
	const bitmap = await createImageBitmap(file);
	let { width, height } = bitmap;
	const scale = Math.min(1, maxEdge / Math.max(width, height));
	width = Math.max(1, Math.round(width * scale));
	height = Math.max(1, Math.round(height * scale));
	const canvas = document.createElement("canvas");
	canvas.width = width;
	canvas.height = height;
	const ctx = canvas.getContext("2d");
	if (!ctx) {
		bitmap.close();
		throw new Error("Canvas is unavailable");
	}
	ctx.fillStyle = "#fffcf7";
	ctx.fillRect(0, 0, width, height);
	ctx.drawImage(bitmap, 0, 0, width, height);
	bitmap.close();
	return {
		blob: await new Promise((resolve, reject) => {
			canvas.toBlob((result) => result ? resolve(result) : reject(/* @__PURE__ */ new Error("Could not encode image")), "image/jpeg", quality);
		}),
		width,
		height
	};
}
async function pdfToPageBlobs(file) {
	const pdfjs = await import("../_libs/pdfjs-dist.mjs").then((n) => n.t);
	const workerMod = await import("./pdf.worker.min-CA4SejP6.mjs");
	pdfjs.GlobalWorkerOptions.workerSrc = workerMod.default;
	const data = await file.arrayBuffer();
	const doc = await pdfjs.getDocument({ data }).promise;
	const truncated = doc.numPages > 12;
	const pageCount = Math.min(doc.numPages, 12);
	const pages = [];
	for (let i = 1; i <= pageCount; i += 1) {
		const page = await doc.getPage(i);
		const viewport = page.getViewport({ scale: 1.6 });
		const canvas = document.createElement("canvas");
		canvas.width = Math.max(1, Math.floor(viewport.width));
		canvas.height = Math.max(1, Math.floor(viewport.height));
		const ctx = canvas.getContext("2d");
		if (!ctx) throw new Error("Canvas is unavailable");
		ctx.fillStyle = "#fffcf7";
		ctx.fillRect(0, 0, canvas.width, canvas.height);
		await page.render({
			canvas,
			canvasContext: ctx,
			viewport
		}).promise;
		const blob = await new Promise((resolve, reject) => {
			canvas.toBlob((result) => result ? resolve(result) : reject(/* @__PURE__ */ new Error("Could not encode page")), "image/jpeg", .86);
		});
		pages.push({
			blob,
			width: canvas.width,
			height: canvas.height,
			page: i,
			pageCount: doc.numPages,
			truncated
		});
	}
	return pages;
}
var SAMPLES = [
	{
		src: "/samples/botanicals.jpg",
		name: "Botanice",
		x: 80,
		y: 248,
		w: 250,
		h: 333
	},
	{
		src: "/samples/courtyard.jpg",
		name: "Curte",
		x: 354,
		y: 248,
		w: 360,
		h: 270
	},
	{
		src: "/samples/paper.jpg",
		name: "Hârtie",
		x: 738,
		y: 248,
		w: 250,
		h: 250
	},
	{
		src: "/samples/ceramics.jpg",
		name: "Ceramica",
		x: 80,
		y: 605,
		w: 250,
		h: 333
	},
	{
		src: "/samples/harbor.jpg",
		name: "Port",
		x: 354,
		y: 734,
		w: 400,
		h: 225
	}
];
function textItem(partial) {
	return {
		type: "text",
		rotation: 0,
		...partial
	};
}
async function buildDemoBoard() {
	const blobs = {};
	const items = [];
	let z = 1;
	items.push(textItem({
		id: crypto.randomUUID(),
		x: 80,
		y: 56,
		w: 520,
		h: 92,
		z: z++,
		content: "Tablou",
		fontSize: 72,
		variant: "display",
		tone: "plain",
		align: "left"
	}), textItem({
		id: crypto.randomUUID(),
		x: 86,
		y: 148,
		w: 460,
		h: 72,
		z: z++,
		content: "Un panou liber pentru imagini, PDF-uri și note.",
		fontSize: 20,
		variant: "note",
		tone: "plain",
		align: "left"
	}));
	await Promise.all(SAMPLES.map(async (sample) => {
		const response = await fetch(sample.src);
		if (!response.ok) return;
		const blob = await response.blob();
		const blobId = crypto.randomUUID();
		blobs[blobId] = blob;
		await blobPut(blobId, blob);
		items.push({
			id: crypto.randomUUID(),
			type: "image",
			blobId,
			name: sample.name,
			source: "sample",
			x: sample.x,
			y: sample.y,
			w: sample.w,
			h: sample.h,
			z: z++,
			rotation: 0
		});
	}));
	items.push(textItem({
		id: crypto.randomUUID(),
		x: 354,
		y: 542,
		w: 280,
		h: 168,
		z: z++,
		content: "Lumină caldă, umbre lungi, hârtie crem. Păstrează paleta restrânsă.",
		fontSize: 18,
		variant: "note",
		tone: "cream",
		align: "left"
	}), textItem({
		id: crypto.randomUUID(),
		x: 738,
		y: 522,
		w: 250,
		h: 188,
		z: z++,
		content: "Trage fișiere pe pânză. Dublu-click pe o notă ca să o editezi.",
		fontSize: 18,
		variant: "note",
		tone: "ink",
		align: "left"
	}));
	return {
		title: "Moodboard de start",
		items,
		blobs
	};
}
function clamp(value, min, max) {
	return Math.min(max, Math.max(min, value));
}
function clampZoom(zoom) {
	return clamp(zoom, ZOOM_MIN, 3);
}
function screenToWorld(clientX, clientY, bounds, pan, zoom) {
	return {
		x: (clientX - bounds.left - pan.x) / zoom,
		y: (clientY - bounds.top - pan.y) / zoom
	};
}
function zoomToward(clientX, clientY, bounds, pan, zoom, nextZoom) {
	const z = clampZoom(nextZoom);
	const world = screenToWorld(clientX, clientY, bounds, pan, zoom);
	return {
		zoom: z,
		pan: {
			x: clientX - bounds.left - world.x * z,
			y: clientY - bounds.top - world.y * z
		}
	};
}
var SAVE_KEY = "board";
function cloneItems(items) {
	return items.map((item) => ({ ...item }));
}
function nextZ(items) {
	return items.reduce((max, item) => Math.max(max, item.z), 0) + 1;
}
function uid() {
	return crypto.randomUUID();
}
var saveTimer = null;
function queueSave(state) {
	if (!state.ready || typeof window === "undefined") return;
	if (saveTimer) window.clearTimeout(saveTimer);
	saveTimer = window.setTimeout(() => {
		kvSet(SAVE_KEY, {
			v: 1,
			title: state.title,
			items: state.items,
			pan: state.pan,
			zoom: state.zoom
		});
	}, 350);
}
function rememberUrls(blobs) {
	const urls = {};
	for (const [id, blob] of Object.entries(blobs)) urls[id] = URL.createObjectURL(blob);
	return urls;
}
var useBoard = create((set, get) => ({
	ready: false,
	title: "Tablou nou",
	items: [],
	selectedIds: [],
	pan: {
		x: 48,
		y: 36
	},
	zoom: 1,
	urls: {},
	past: [],
	future: [],
	needsFit: false,
	hydrate: async () => {
		try {
			const saved = await kvGet(SAVE_KEY);
			if (saved?.v === 1 && saved.items?.length) {
				const urls = {};
				for (const item of saved.items) {
					if (item.type !== "image") continue;
					const blob = await blobGet(item.blobId);
					if (blob) urls[item.blobId] = URL.createObjectURL(blob);
				}
				set({
					ready: true,
					title: saved.title || "Tablou nou",
					items: saved.items,
					pan: saved.pan ?? {
						x: 48,
						y: 36
					},
					zoom: saved.zoom ?? 1,
					urls,
					selectedIds: [],
					past: [],
					future: [],
					needsFit: false
				});
				return;
			}
		} catch {}
		await get().loadDemo();
	},
	setTitle: (title) => {
		set({ title });
		queueSave(get());
	},
	setView: (pan, zoom) => {
		set({
			pan,
			zoom: clampZoom(zoom)
		});
		queueSave(get());
	},
	select: (ids, additive = false) => {
		set((state) => {
			if (!additive) return { selectedIds: ids };
			const next = new Set(state.selectedIds);
			for (const id of ids) if (next.has(id)) next.delete(id);
			else next.add(id);
			return { selectedIds: [...next] };
		});
	},
	clearSelection: () => set({ selectedIds: [] }),
	pushHistory: () => {
		const { title, items, past } = get();
		set({
			past: [...past, {
				title,
				items: cloneItems(items)
			}].slice(-50),
			future: []
		});
	},
	undo: () => {
		const { past, future, title, items } = get();
		const prev = past[past.length - 1];
		if (!prev) return;
		set({
			past: past.slice(0, -1),
			future: [...future, {
				title,
				items: cloneItems(items)
			}],
			title: prev.title,
			items: cloneItems(prev.items),
			selectedIds: []
		});
		queueSave(get());
	},
	redo: () => {
		const { past, future, title, items } = get();
		const next = future[future.length - 1];
		if (!next) return;
		set({
			future: future.slice(0, -1),
			past: [...past, {
				title,
				items: cloneItems(items)
			}],
			title: next.title,
			items: cloneItems(next.items),
			selectedIds: []
		});
		queueSave(get());
	},
	moveItems: (ids, dx, dy) => {
		if (!dx && !dy) return;
		const idSet = new Set(ids);
		set((state) => ({ items: state.items.map((item) => idSet.has(item.id) ? {
			...item,
			x: item.x + dx,
			y: item.y + dy
		} : item) }));
		queueSave(get());
	},
	placeItems: (positions) => {
		if (!positions.length) return;
		const map = new Map(positions.map((entry) => [entry.id, entry]));
		set((state) => ({ items: state.items.map((item) => {
			const next = map.get(item.id);
			return next ? {
				...item,
				x: next.x,
				y: next.y
			} : item;
		}) }));
		queueSave(get());
	},
	resizeItem: (id, next) => {
		set((state) => ({ items: state.items.map((item) => item.id === id ? {
			...item,
			x: next.x,
			y: next.y,
			w: Math.max(80, next.w),
			h: Math.max(64, next.h)
		} : item) }));
		queueSave(get());
	},
	addTextAt: (x, y, tone = "cream") => {
		get().pushHistory();
		const item = {
			id: uid(),
			type: "text",
			x,
			y,
			w: 240,
			h: 160,
			z: nextZ(get().items),
			rotation: 0,
			content: "Notă nouă",
			fontSize: 18,
			variant: "note",
			tone,
			align: "left"
		};
		set((state) => ({
			items: [...state.items, item],
			selectedIds: [item.id]
		}));
		queueSave(get());
	},
	ingestFiles: async (files, at) => {
		get().pushHistory();
		let added = 0;
		let skipped = 0;
		let truncatedPdf = false;
		let offset = 0;
		const created = [];
		const urls = {};
		for (const file of files) try {
			if (isPdfFile(file)) {
				const pages = await pdfToPageBlobs(file);
				if (pages[0]?.truncated) truncatedPdf = true;
				for (const page of pages) {
					const blobId = uid();
					await blobPut(blobId, page.blob);
					urls[blobId] = URL.createObjectURL(page.blob);
					const size = fitPinSize(page.width, page.height);
					const item = {
						id: uid(),
						type: "image",
						blobId,
						name: file.name,
						source: "pdf",
						page: page.page,
						pageCount: page.pageCount,
						x: at.x + offset,
						y: at.y + offset,
						w: size.w,
						h: size.h,
						z: nextZ([...get().items, ...created]),
						rotation: 0
					};
					created.push(item);
					offset += 28;
					added += 1;
				}
			} else if (isImageFile(file)) {
				const jpeg = await fileToJpegBlob(file);
				const blobId = uid();
				await blobPut(blobId, jpeg.blob);
				urls[blobId] = URL.createObjectURL(jpeg.blob);
				const size = fitPinSize(jpeg.width, jpeg.height);
				const item = {
					id: uid(),
					type: "image",
					blobId,
					name: file.name,
					source: "upload",
					x: at.x + offset,
					y: at.y + offset,
					w: size.w,
					h: size.h,
					z: nextZ([...get().items, ...created]),
					rotation: 0
				};
				created.push(item);
				offset += 28;
				added += 1;
			} else skipped += 1;
		} catch {
			skipped += 1;
		}
		if (created.length) {
			set((state) => ({
				items: [...state.items, ...created],
				urls: {
					...state.urls,
					...urls
				},
				selectedIds: created.map((item) => item.id)
			}));
			queueSave(get());
		}
		return {
			added,
			skipped,
			truncatedPdf
		};
	},
	ingestBlob: async (blob, name, at) => {
		const file = new File([blob], name, { type: blob.type || "image/jpeg" });
		await get().ingestFiles([file], at);
	},
	updateText: (id, content) => {
		set((state) => ({ items: state.items.map((item) => item.id === id && item.type === "text" ? {
			...item,
			content
		} : item) }));
		queueSave(get());
	},
	removeSelected: () => {
		const { selectedIds } = get();
		if (!selectedIds.length) return;
		get().pushHistory();
		const idSet = new Set(selectedIds);
		set((state) => ({
			items: state.items.filter((item) => !idSet.has(item.id)),
			selectedIds: []
		}));
		queueSave(get());
	},
	duplicateSelected: () => {
		const { selectedIds, items } = get();
		if (!selectedIds.length) return;
		get().pushHistory();
		const idSet = new Set(selectedIds);
		const copies = [];
		let z = nextZ(items);
		for (const item of items) {
			if (!idSet.has(item.id)) continue;
			copies.push({
				...item,
				id: uid(),
				x: item.x + 28,
				y: item.y + 28,
				z: z++
			});
		}
		set((state) => ({
			items: [...state.items, ...copies],
			selectedIds: copies.map((item) => item.id)
		}));
		queueSave(get());
	},
	bringToFront: () => {
		const { selectedIds, items } = get();
		if (!selectedIds.length) return;
		get().pushHistory();
		const idSet = new Set(selectedIds);
		let z = nextZ(items);
		set({ items: items.map((item) => idSet.has(item.id) ? {
			...item,
			z: z++
		} : item) });
		queueSave(get());
	},
	sendToBack: () => {
		const { selectedIds, items } = get();
		if (!selectedIds.length) return;
		get().pushHistory();
		const idSet = new Set(selectedIds);
		let z = items.reduce((min, item) => Math.min(min, item.z), Number.POSITIVE_INFINITY) - selectedIds.length;
		set({ items: items.map((item) => idSet.has(item.id) ? {
			...item,
			z: z++
		} : item) });
		queueSave(get());
	},
	rotateSelected: (delta) => {
		const { selectedIds } = get();
		if (!selectedIds.length) return;
		get().pushHistory();
		const idSet = new Set(selectedIds);
		set((state) => ({ items: state.items.map((item) => idSet.has(item.id) ? {
			...item,
			rotation: item.rotation + delta
		} : item) }));
		queueSave(get());
	},
	packGrid: () => {
		const { items } = get();
		if (!items.length) return;
		get().pushHistory();
		const colWidth = 250;
		const gap = 24;
		const cols = 4;
		const heights = Array.from({ length: cols }, () => 0);
		const originX = 80;
		const originY = 80;
		set({
			items: [...items].sort((a, b) => a.z - b.z).map((item) => {
				const scale = colWidth / item.w;
				const w = colWidth;
				const h = Math.max(80, Math.round(item.h * scale));
				let col = 0;
				for (let i = 1; i < cols; i += 1) if (heights[i] < heights[col]) col = i;
				const x = originX + col * 274;
				const y = originY + heights[col];
				heights[col] += h + gap;
				return {
					...item,
					x,
					y,
					w,
					h,
					rotation: 0
				};
			}),
			selectedIds: []
		});
		queueSave(get());
	},
	fitView: (viewport) => {
		const { items } = get();
		if (!items.length) {
			set({
				pan: {
					x: 48,
					y: 36
				},
				zoom: 1
			});
			queueSave(get());
			return;
		}
		let minX = Infinity;
		let minY = Infinity;
		let maxX = -Infinity;
		let maxY = -Infinity;
		for (const item of items) {
			minX = Math.min(minX, item.x);
			minY = Math.min(minY, item.y);
			maxX = Math.max(maxX, item.x + item.w);
			maxY = Math.max(maxY, item.y + item.h);
		}
		const w = Math.max(1, maxX - minX);
		const h = Math.max(1, maxY - minY);
		const zoom = clampZoom(Math.min((viewport.w - 192) / w, (viewport.h - 192) / h, 1.25));
		set({
			zoom,
			pan: {
				x: (viewport.w - w * zoom) / 2 - minX * zoom,
				y: (viewport.h - h * zoom) / 2 - minY * zoom
			}
		});
		queueSave(get());
	},
	markFitted: () => set({ needsFit: false }),
	clearBoard: () => {
		get().pushHistory();
		set({
			items: [],
			selectedIds: [],
			title: "Tablou nou"
		});
		queueSave(get());
	},
	loadDemo: async () => {
		try {
			const demo = await buildDemoBoard();
			const urls = rememberUrls(demo.blobs);
			set({
				ready: true,
				title: demo.title,
				items: demo.items,
				urls: {
					...get().urls,
					...urls
				},
				selectedIds: [],
				pan: {
					x: 36,
					y: 24
				},
				zoom: .92,
				past: [],
				future: [],
				needsFit: true
			});
			queueSave(get());
		} catch {
			set({
				ready: true,
				title: "Tablou nou",
				items: [],
				selectedIds: [],
				pan: {
					x: 48,
					y: 36
				},
				zoom: 1,
				needsFit: false
			});
		}
	}
}));
var HANDLES = [
	"nw",
	"ne",
	"sw",
	"se"
];
var HANDLE_CLASS = {
	nw: "left-0 top-0 -translate-x-1/2 -translate-y-1/2 cursor-nwse-resize",
	ne: "right-0 top-0 translate-x-1/2 -translate-y-1/2 cursor-nesw-resize",
	sw: "bottom-0 left-0 -translate-x-1/2 translate-y-1/2 cursor-nesw-resize",
	se: "bottom-0 right-0 translate-x-1/2 translate-y-1/2 cursor-nwse-resize"
};
function BoardItemView({ item, selected, zoom: _zoom, editing, onItemPointerDown, onHandlePointerDown, onStartEdit, onEndEdit }) {
	const url = useBoard((state) => item.type === "image" ? state.urls[item.blobId] : void 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		"data-board-item": item.id,
		className: cn("absolute origin-center", selected && "z-20"),
		style: {
			left: item.x,
			top: item.y,
			width: item.w,
			height: item.h,
			zIndex: selected ? 1e4 + item.z : item.z,
			transform: `rotate(${item.rotation}deg)`
		},
		onPointerDown: (event) => onItemPointerDown(event, item.id),
		onDoubleClick: (event) => {
			if (item.type !== "text") return;
			event.stopPropagation();
			onStartEdit(item.id);
		},
		children: [
			item.type === "image" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImagePin, {
				item,
				url
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextPin, {
				item,
				editing,
				onEndEdit
			}),
			selected ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute inset-0 rounded-[2px] ring-2 ring-primary" }) : null,
			selected ? HANDLES.map((handle) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				"aria-label": `Redimensionează ${handle}`,
				className: cn("resize-handle pointer-events-auto z-10", HANDLE_CLASS[handle]),
				onPointerDown: (event) => onHandlePointerDown(event, item.id, handle)
			}, handle)) : null
		]
	});
}
function ImagePin({ item, url }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "pin-card relative h-full w-full rounded-sm p-2 pb-7",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "pin-head",
				"aria-hidden": true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "relative h-full w-full overflow-hidden rounded-[2px] bg-surface-2",
				children: url ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: url,
					alt: item.name,
					draggable: false,
					crossOrigin: "anonymous",
					className: "size-full object-cover select-none"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "size-full animate-pulse bg-surface-2" })
			}),
			item.source === "pdf" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "absolute right-2 bottom-1.5 left-2 flex items-center gap-1 text-xs tracking-wide text-muted",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "size-3" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "truncate",
					children: [item.name, item.page ? ` · ${item.page}` : ""]
				})]
			}) : null
		]
	});
}
function TextPin({ item, editing, onEndEdit }) {
	const updateText = useBoard((state) => state.updateText);
	const toneClass = item.tone === "ink" ? "note-ink" : item.tone === "cream" ? "note-cream" : "note-plain";
	const isDisplay = item.variant === "display";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("relative h-full w-full overflow-hidden", toneClass, isDisplay ? "rounded-none px-1 py-1" : "rounded-md px-4 py-4"),
		children: [item.tone !== "plain" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "pin-head",
			"aria-hidden": true
		}) : null, editing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
			autoFocus: true,
			defaultValue: item.content,
			onPointerDown: (event) => event.stopPropagation(),
			onBlur: (event) => {
				updateText(item.id, event.currentTarget.value);
				onEndEdit();
			},
			onKeyDown: (event) => {
				if (event.key === "Escape") event.currentTarget.blur();
				event.stopPropagation();
			},
			className: cn("h-full w-full resize-none bg-transparent outline-none", isDisplay ? "font-display font-medium tracking-tight" : "leading-normal", item.align === "center" && "text-center"),
			style: { fontSize: item.fontSize }
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: cn("h-full w-full overflow-hidden whitespace-pre-wrap break-words", isDisplay ? "font-display font-medium tracking-tight leading-tight" : "leading-normal", item.align === "center" && "text-center"),
			style: { fontSize: item.fontSize },
			children: item.content
		})]
	});
}
function applyResize(handle, dx, dy, orig, lockAspect) {
	const ratio = orig.w / Math.max(1, orig.h);
	let { x, y, w, h } = orig;
	if (lockAspect) {
		if (handle === "se" || handle === "ne") {
			w = orig.w + dx;
			h = w / ratio;
			if (handle === "ne") y = orig.y + orig.h - h;
		} else {
			w = orig.w - dx;
			h = w / ratio;
			x = orig.x + orig.w - w;
			if (handle === "nw") y = orig.y + orig.h - h;
		}
	} else if (handle === "se") {
		w = orig.w + dx;
		h = orig.h + dy;
	} else if (handle === "sw") {
		w = orig.w - dx;
		h = orig.h + dy;
		x = orig.x + dx;
	} else if (handle === "ne") {
		w = orig.w + dx;
		h = orig.h - dy;
		y = orig.y + dy;
	} else {
		w = orig.w - dx;
		h = orig.h - dy;
		x = orig.x + dx;
		y = orig.y + dy;
	}
	const minW = 80;
	const minH = 64;
	if (w < minW) {
		if (handle === "nw" || handle === "sw") x = orig.x + orig.w - minW;
		w = minW;
		if (lockAspect) {
			h = w / ratio;
			if (handle === "nw" || handle === "ne") y = orig.y + orig.h - h;
		}
	}
	if (h < minH) {
		if (handle === "nw" || handle === "ne") y = orig.y + orig.h - minH;
		h = minH;
		if (lockAspect) {
			w = h * ratio;
			if (handle === "nw" || handle === "sw") x = orig.x + orig.w - w;
		}
	}
	return {
		x,
		y,
		w,
		h
	};
}
function BoardCanvas({ dropping, onDropFiles, viewportRef }) {
	const gesture = (0, import_react.useRef)(null);
	const pointers = (0, import_react.useRef)(/* @__PURE__ */ new Map());
	const spaceHeld = (0, import_react.useRef)(false);
	const [editingId, setEditingId] = (0, import_react.useState)(null);
	const items = useBoard((state) => state.items);
	const selectedIds = useBoard((state) => state.selectedIds);
	const pan = useBoard((state) => state.pan);
	const zoom = useBoard((state) => state.zoom);
	const select = useBoard((state) => state.select);
	const clearSelection = useBoard((state) => state.clearSelection);
	const setView = useBoard((state) => state.setView);
	const pushHistory = useBoard((state) => state.pushHistory);
	const placeItems = useBoard((state) => state.placeItems);
	const resizeItem = useBoard((state) => state.resizeItem);
	const bounds = (0, import_react.useCallback)(() => {
		const el = viewportRef.current;
		if (!el) return new DOMRect();
		return el.getBoundingClientRect();
	}, []);
	(0, import_react.useEffect)(() => {
		const onKeyDown = (event) => {
			if (event.code === "Space") spaceHeld.current = true;
		};
		const onKeyUp = (event) => {
			if (event.code === "Space") spaceHeld.current = false;
		};
		window.addEventListener("keydown", onKeyDown);
		window.addEventListener("keyup", onKeyUp);
		window.addEventListener("blur", () => {
			spaceHeld.current = false;
		});
		return () => {
			window.removeEventListener("keydown", onKeyDown);
			window.removeEventListener("keyup", onKeyUp);
		};
	}, []);
	(0, import_react.useEffect)(() => {
		const node = viewportRef.current;
		if (!node) return;
		const onWheel = (event) => {
			event.preventDefault();
			const state = useBoard.getState();
			const factor = event.deltaY > 0 ? .92 : 1.08;
			const next = zoomToward(event.clientX, event.clientY, node.getBoundingClientRect(), state.pan, state.zoom, state.zoom * factor);
			state.setView(next.pan, next.zoom);
		};
		node.addEventListener("wheel", onWheel, { passive: false });
		return () => node.removeEventListener("wheel", onWheel);
	}, []);
	const endGesture = (0, import_react.useCallback)(() => {
		gesture.current = null;
	}, []);
	const onItemPointerDown = (event, id) => {
		if (event.button !== 0) return;
		if (editingId) return;
		event.stopPropagation();
		const state = useBoard.getState();
		const already = state.selectedIds.includes(id);
		const nextIds = event.shiftKey ? already ? state.selectedIds.filter((value) => value !== id) : [...state.selectedIds, id] : already ? state.selectedIds : [id];
		state.select(nextIds);
		const movingIds = nextIds.length ? nextIds : [id];
		const origins = state.items.filter((item) => movingIds.includes(item.id)).map((item) => ({
			id: item.id,
			x: item.x,
			y: item.y
		}));
		state.pushHistory();
		gesture.current = {
			kind: "move",
			pointerId: event.pointerId,
			sx: event.clientX,
			sy: event.clientY,
			origins
		};
		event.currentTarget.setPointerCapture(event.pointerId);
	};
	const onHandlePointerDown = (event, id, handle) => {
		if (event.button !== 0) return;
		event.stopPropagation();
		const item = useBoard.getState().items.find((entry) => entry.id === id);
		if (!item) return;
		pushHistory();
		select([id]);
		gesture.current = {
			kind: "resize",
			pointerId: event.pointerId,
			sx: event.clientX,
			sy: event.clientY,
			id,
			handle,
			orig: {
				x: item.x,
				y: item.y,
				w: item.w,
				h: item.h
			},
			lockAspect: item.type === "image" && !event.shiftKey
		};
		event.currentTarget.setPointerCapture(event.pointerId);
	};
	const onViewportPointerDown = (event) => {
		if (event.button === 2) return;
		if (event.target.closest("[data-board-item]")) return;
		setEditingId(null);
		if (!event.shiftKey) clearSelection();
		pointers.current.set(event.pointerId, {
			x: event.clientX,
			y: event.clientY
		});
		if (pointers.current.size === 2) {
			const pts = [...pointers.current.values()];
			const a = pts[0];
			const b = pts[1];
			gesture.current = {
				kind: "pan",
				pointerId: event.pointerId,
				sx: (a.x + b.x) / 2,
				sy: (a.y + b.y) / 2,
				panX: pan.x,
				panY: pan.y
			};
			return;
		}
		gesture.current = {
			kind: "pan",
			pointerId: event.pointerId,
			sx: event.clientX,
			sy: event.clientY,
			panX: pan.x,
			panY: pan.y
		};
		event.currentTarget.setPointerCapture(event.pointerId);
	};
	const onPointerMove = (event) => {
		if (pointers.current.has(event.pointerId)) pointers.current.set(event.pointerId, {
			x: event.clientX,
			y: event.clientY
		});
		if (pointers.current.size === 2) {
			const pts = [...pointers.current.values()];
			const a = pts[0];
			const b = pts[1];
			const dist = Math.hypot(a.x - b.x, a.y - b.y);
			const pinch = gesture.current;
			if (pinch && "startDist" in pinch && pinch.startDist) {
				const next = zoomToward((a.x + b.x) / 2, (a.y + b.y) / 2, bounds(), useBoard.getState().pan, useBoard.getState().zoom, (pinch.startZoom ?? 1) * (dist / pinch.startDist));
				setView(next.pan, next.zoom);
				return;
			}
			const state = useBoard.getState();
			gesture.current = {
				kind: "pan",
				pointerId: event.pointerId,
				sx: (a.x + b.x) / 2,
				sy: (a.y + b.y) / 2,
				panX: state.pan.x,
				panY: state.pan.y,
				startDist: dist,
				startZoom: state.zoom
			};
			return;
		}
		const g = gesture.current;
		if (!g) return;
		const state = useBoard.getState();
		if (g.kind === "pan") {
			setView({
				x: g.panX + (event.clientX - g.sx),
				y: g.panY + (event.clientY - g.sy)
			}, state.zoom);
			return;
		}
		if (g.kind === "move") {
			const dx = (event.clientX - g.sx) / state.zoom;
			const dy = (event.clientY - g.sy) / state.zoom;
			placeItems(g.origins.map((origin) => ({
				id: origin.id,
				x: origin.x + dx,
				y: origin.y + dy
			})));
			return;
		}
		if (g.kind === "resize") {
			const dx = (event.clientX - g.sx) / state.zoom;
			const dy = (event.clientY - g.sy) / state.zoom;
			resizeItem(g.id, applyResize(g.handle, dx, dy, g.orig, g.lockAspect));
		}
	};
	const onPointerUp = (event) => {
		pointers.current.delete(event.pointerId);
		if (gesture.current && "pointerId" in gesture.current) {
			if (gesture.current.pointerId === event.pointerId) endGesture();
		}
		if (pointers.current.size === 0) endGesture();
	};
	const onDragOver = (event) => {
		event.preventDefault();
	};
	const onDrop = (event) => {
		event.preventDefault();
		const files = [...event.dataTransfer.files];
		if (files.length) onDropFiles(files, event.clientX, event.clientY);
	};
	const sorted = [...items].sort((a, b) => a.z - b.z);
	const empty = items.length === 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		ref: viewportRef,
		className: cn("board-viewport relative h-full w-full overflow-hidden", spaceHeld.current ? "cursor-grab" : "cursor-default"),
		style: {
			backgroundSize: `${28 * zoom}px ${28 * zoom}px`,
			backgroundPosition: `${pan.x}px ${pan.y}px`
		},
		onPointerDown: onViewportPointerDown,
		onPointerMove,
		onPointerUp,
		onPointerCancel: onPointerUp,
		onDragOver,
		onDrop,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute top-0 left-0 will-change-transform",
				style: {
					transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom})`,
					transformOrigin: "0 0"
				},
				children: sorted.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BoardItemView, {
					item,
					selected: selectedIds.includes(item.id),
					zoom,
					editing: editingId === item.id,
					onItemPointerDown,
					onHandlePointerDown,
					onStartEdit: (id) => {
						pushHistory();
						select([id]);
						setEditingId(id);
					},
					onEndEdit: () => setEditingId(null)
				}, item.id))
			}),
			empty ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pointer-events-none absolute inset-0 flex items-center justify-center p-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "max-w-sm rounded-xl border border-border bg-card/90 px-6 py-8 text-center shadow-pin",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mx-auto mb-4 flex size-12 items-center justify-center rounded-lg bg-surface-2 text-primary",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImagePlus, { className: "size-5" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-xl font-medium tracking-tight",
							children: "Pânza e goală"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-muted",
							children: "Adaugă o imagine, un PDF sau o notă — apoi aranjează-le liber."
						})
					]
				})
			}) : null,
			dropping ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pointer-events-none absolute inset-3 flex items-center justify-center rounded-xl border-2 border-dashed border-primary bg-primary/10",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-lg text-primary",
					children: "Eliberează imaginile sau PDF-urile"
				})
			}) : null
		]
	});
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap font-medium transition-[color,background-color,box-shadow,transform,opacity] duration-150 ease-out focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-bg disabled:pointer-events-none disabled:opacity-40 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0", {
	variants: {
		variant: {
			default: "bg-primary text-primary-fg hover:bg-primary/90",
			secondary: "bg-surface text-fg border border-border hover:bg-surface-2",
			ghost: "text-fg hover:bg-surface-2",
			outline: "border border-border bg-transparent text-fg hover:bg-surface",
			danger: "bg-danger text-primary-fg hover:bg-danger/90"
		},
		size: {
			md: "h-10 rounded-md px-3.5 text-sm",
			sm: "h-8 rounded-sm px-2.5 text-xs",
			lg: "h-11 rounded-md px-4 text-sm",
			icon: "size-10 rounded-md",
			toolbar: "size-11 rounded-md"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "md"
	}
});
function Button({ className, variant, size, asChild = false, unstyled = false, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size
		}), !unstyled && "active:not-disabled:scale-[0.96]", className),
		...props
	});
}
var DropdownMenu = Root2;
var DropdownMenuTrigger = Trigger;
function DropdownMenuContent({ className, sideOffset = 8, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portal2, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content2, {
		sideOffset,
		className: cn("z-50 min-w-48 overflow-hidden rounded-lg border border-border bg-card p-1.5 text-fg shadow-pin", "data-[state=open]:animate-in data-[state=closed]:animate-out", "data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", "data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95", className),
		...props
	}) });
}
function DropdownMenuItem({ className, inset, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item2, {
		className: cn("flex cursor-pointer items-center gap-2 rounded-sm px-2.5 py-2 text-sm outline-none", "focus:bg-surface-2 data-[disabled]:pointer-events-none data-[disabled]:opacity-40", inset && "pl-8", className),
		...props
	});
}
function DropdownMenuSeparator({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Separator2, {
		className: cn("my-1 h-px bg-border", className),
		...props
	});
}
function BoardHeader({ onHelp, onFit }) {
	const title = useBoard((state) => state.title);
	const setTitle = useBoard((state) => state.setTitle);
	const clearBoard = useBoard((state) => state.clearBoard);
	const loadDemo = useBoard((state) => state.loadDemo);
	const undo = useBoard((state) => state.undo);
	const redo = useBoard((state) => state.redo);
	const canUndo = useBoard((state) => state.past.length > 0);
	const canRedo = useBoard((state) => state.future.length > 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "pointer-events-none absolute inset-x-0 top-0 z-30 flex items-start justify-between gap-3 p-3 pt-[max(0.75rem,env(safe-area-inset-top))]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "pointer-events-auto flex min-w-0 items-center gap-3 rounded-lg border border-border bg-card/95 py-2 pr-3 pl-2.5 shadow-pin backdrop-blur-sm",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex size-9 shrink-0 items-center justify-center rounded-sm bg-primary font-display text-lg font-medium text-primary-fg",
				"aria-hidden": true,
				children: "T"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium tracking-wide text-muted uppercase",
					children: "Tablou"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: title,
					onChange: (event) => setTitle(event.target.value),
					"aria-label": "Titlul tabloului",
					className: "w-full min-w-32 truncate bg-transparent font-display text-base font-medium tracking-tight outline-none md:min-w-48"
				})]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "pointer-events-auto flex items-center gap-1.5 rounded-lg border border-border bg-card/95 p-1.5 shadow-pin backdrop-blur-sm",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "button",
				variant: "ghost",
				size: "icon",
				"aria-label": "Ajutor",
				onClick: onHelp,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleHelp, {})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenu, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuTrigger, {
				asChild: true,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					variant: "ghost",
					size: "icon",
					"aria-label": "Mai multe",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ellipsis, {})
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuContent, {
				align: "end",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuItem, {
						onSelect: onFit,
						children: "Potrivește în ecran"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuItem, {
						onSelect: () => undo(),
						disabled: !canUndo,
						children: "Anulează"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuItem, {
						onSelect: () => redo(),
						disabled: !canRedo,
						children: "Refă"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuSeparator, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuItem, {
						onSelect: () => void loadDemo(),
						children: "Încarcă exemplul"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuItem, {
						onSelect: clearBoard,
						children: "Golește pânza"
					})
				]
			})] })]
		})]
	});
}
var Dialog = Dialog$1;
function DialogOverlay({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay$1, {
		className: cn("fixed inset-0 z-50 bg-fg/30 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", className),
		...props
	});
}
function DialogContent({ className, children, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent$1, {
		className: cn("fixed top-1/2 left-1/2 z-50 w-[min(100%-2rem,28rem)] -translate-x-1/2 -translate-y-1/2 rounded-xl border border-border bg-card p-6 text-fg shadow-pin", "data-[state=open]:animate-in data-[state=closed]:animate-out", "data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", "data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95", className),
		...props,
		children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogClose, {
			className: "absolute top-3 right-3 rounded-sm p-2 text-muted hover:bg-surface-2 hover:text-fg",
			"aria-label": "Închide",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
		})]
	})] });
}
function DialogHeader({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("mb-4 space-y-1.5", className),
		...props
	});
}
function DialogTitle({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle$1, {
		className: cn("font-display text-xl font-medium tracking-tight", className),
		...props
	});
}
function DialogDescription({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription$1, {
		className: cn("text-sm text-muted", className),
		...props
	});
}
var ROWS = [
	["Trage pe pânză", "Deplasează vederea"],
	["Roata mouse-ului", "Zoom spre cursor"],
	["Trage un element", "Mută pe pânză"],
	["Colțurile selecției", "Redimensionează"],
	["Dublu-click pe notă", "Editează textul"],
	["Delete / Backspace", "Șterge selecția"],
	["Ctrl/Cmd + Z", "Anulează"],
	["Ctrl/Cmd + D", "Duplică"]
];
function HelpDialog({ open, onOpenChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Cum lucrezi pe Tablou" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "Inserează imagini JPG, documente PDF și casete text, apoi aranjează-le liber — ca pe un panou de inspirație." })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "space-y-2",
			children: ROWS.map(([action, result]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "flex items-baseline justify-between gap-4 border-b border-border py-2 last:border-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-sm font-medium",
					children: action
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-right text-sm text-muted",
					children: result
				})]
			}, action))
		})] })
	});
}
function TooltipProvider({ delayDuration = 280, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Provider, {
		delayDuration,
		...props
	});
}
var Tooltip = Root3;
var TooltipTrigger = Trigger$1;
function TooltipContent({ className, sideOffset = 6, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content2$1, {
		sideOffset,
		className: cn("z-50 rounded-sm bg-fg px-2 py-1 text-xs text-bg shadow-none", "data-[state=delayed-open]:animate-in data-[state=closed]:animate-out", "data-[state=closed]:fade-out-0 data-[state=delayed-open]:fade-in-0", className),
		...props
	}) });
}
function Tip({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tooltip, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipTrigger, {
		asChild: true,
		children
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipContent, { children: label })] });
}
function BoardToolbar({ onAddFiles, onAddText, onZoomBy, onFit }) {
	const imageInput = (0, import_react.useRef)(null);
	const pdfInput = (0, import_react.useRef)(null);
	const selectedCount = useBoard((state) => state.selectedIds.length);
	const zoom = useBoard((state) => state.zoom);
	const duplicateSelected = useBoard((state) => state.duplicateSelected);
	const bringToFront = useBoard((state) => state.bringToFront);
	const rotateSelected = useBoard((state) => state.rotateSelected);
	const removeSelected = useBoard((state) => state.removeSelected);
	const packGrid = useBoard((state) => state.packGrid);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "pointer-events-none absolute inset-x-0 bottom-0 z-30 flex justify-center p-3 pb-[max(0.75rem,env(safe-area-inset-bottom))]",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "pointer-events-auto flex max-w-full items-center gap-1 overflow-x-auto rounded-xl border border-border bg-card/95 p-1.5 shadow-pin backdrop-blur-sm",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					ref: imageInput,
					type: "file",
					accept: "image/jpeg,image/jpg,image/png,image/webp,image/gif",
					multiple: true,
					className: "hidden",
					onChange: (event) => {
						const files = [...event.target.files ?? []];
						event.target.value = "";
						if (files.length) onAddFiles(files);
					}
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					ref: pdfInput,
					type: "file",
					accept: "application/pdf,.pdf",
					multiple: true,
					className: "hidden",
					onChange: (event) => {
						const files = [...event.target.files ?? []];
						event.target.value = "";
						if (files.length) onAddFiles(files);
					}
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tip, {
					label: "Adaugă imagine",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "ghost",
						size: "toolbar",
						"aria-label": "Adaugă imagine",
						onClick: () => imageInput.current?.click(),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImagePlus, {})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tip, {
					label: "Adaugă PDF",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "ghost",
						size: "toolbar",
						"aria-label": "Adaugă PDF",
						onClick: () => pdfInput.current?.click(),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, {})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tip, {
					label: "Adaugă notă",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "ghost",
						size: "toolbar",
						"aria-label": "Adaugă notă",
						onClick: onAddText,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Type, {})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mx-1 hidden h-6 w-px bg-border sm:block" }),
				selectedCount > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tip, {
						label: "Duplică",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "ghost",
							size: "toolbar",
							"aria-label": "Duplică",
							onClick: duplicateSelected,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, {})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tip, {
						label: "Rotește",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "ghost",
							size: "toolbar",
							"aria-label": "Rotește",
							onClick: () => rotateSelected(12),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCw, {})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tip, {
						label: "Șterge",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "ghost",
							size: "toolbar",
							"aria-label": "Șterge",
							onClick: removeSelected,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "hidden h-11 rounded-md px-2 text-xs font-medium text-muted hover:bg-surface-2 hover:text-fg sm:inline",
						onClick: bringToFront,
						children: "În față"
					})
				] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tip, {
					label: "Aranjează în grilă",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "ghost",
						size: "toolbar",
						"aria-label": "Aranjează în grilă",
						onClick: packGrid,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LayoutGrid, {})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mx-1 hidden h-6 w-px bg-border sm:block" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tip, {
					label: "Micșorează",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "ghost",
						size: "toolbar",
						"aria-label": "Micșorează",
						onClick: () => onZoomBy(.9),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ZoomOut, {})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: onFit,
					className: "hidden h-11 min-w-14 rounded-md px-2 font-medium tabular-nums text-muted hover:bg-surface-2 hover:text-fg sm:inline",
					"aria-label": "Potrivește în ecran",
					children: [Math.round(zoom * 100), "%"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tip, {
					label: "Mărește",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "ghost",
						size: "toolbar",
						"aria-label": "Mărește",
						onClick: () => onZoomBy(1.1),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ZoomIn, {})
					})
				})
			]
		})
	});
}
function BoardApp() {
	const viewportRef = (0, import_react.useRef)(null);
	const [helpOpen, setHelpOpen] = (0, import_react.useState)(false);
	const [dropping, setDropping] = (0, import_react.useState)(false);
	const dragDepth = (0, import_react.useRef)(0);
	const ready = useBoard((state) => state.ready);
	const hydrate = useBoard((state) => state.hydrate);
	const needsFit = useBoard((state) => state.needsFit);
	const fitView = useBoard((state) => state.fitView);
	const markFitted = useBoard((state) => state.markFitted);
	const ingestFiles = useBoard((state) => state.ingestFiles);
	const addTextAt = useBoard((state) => state.addTextAt);
	const undo = useBoard((state) => state.undo);
	const redo = useBoard((state) => state.redo);
	const removeSelected = useBoard((state) => state.removeSelected);
	const duplicateSelected = useBoard((state) => state.duplicateSelected);
	const select = useBoard((state) => state.select);
	(0, import_react.useEffect)(() => {
		hydrate();
	}, [hydrate]);
	(0, import_react.useEffect)(() => {
		if (!ready || !needsFit) return;
		const node = viewportRef.current;
		if (!node) return;
		fitView({
			w: node.clientWidth,
			h: node.clientHeight
		});
		markFitted();
	}, [
		ready,
		needsFit,
		fitView,
		markFitted
	]);
	(0, import_react.useEffect)(() => {
		const onKeyDown = (event) => {
			const target = event.target;
			const typing = target && (target.tagName === "INPUT" || target.tagName === "TEXTAREA" || target.isContentEditable);
			const meta = event.metaKey || event.ctrlKey;
			if (event.code === "Space" && !typing) event.preventDefault();
			if (event.key === "?" && !typing) {
				event.preventDefault();
				setHelpOpen(true);
				return;
			}
			if (typing) return;
			if (meta && event.key.toLowerCase() === "z") {
				event.preventDefault();
				if (event.shiftKey) redo();
				else undo();
				return;
			}
			if (meta && event.key.toLowerCase() === "d") {
				event.preventDefault();
				duplicateSelected();
				return;
			}
			if (meta && event.key.toLowerCase() === "a") {
				event.preventDefault();
				select(useBoard.getState().items.map((item) => item.id));
				return;
			}
			if (event.key === "Delete" || event.key === "Backspace") {
				event.preventDefault();
				removeSelected();
			}
		};
		const onPaste = (event) => {
			const target = event.target;
			if (target && (target.tagName === "INPUT" || target.tagName === "TEXTAREA" || target.isContentEditable)) return;
			const items = event.clipboardData?.files;
			if (items && items.length) {
				event.preventDefault();
				handleFiles([...items]);
			}
		};
		window.addEventListener("keydown", onKeyDown);
		window.addEventListener("paste", onPaste);
		return () => {
			window.removeEventListener("keydown", onKeyDown);
			window.removeEventListener("paste", onPaste);
		};
	}, [
		undo,
		redo,
		removeSelected,
		duplicateSelected,
		select
	]);
	function centerWorld() {
		const node = viewportRef.current;
		const state = useBoard.getState();
		if (!node) return {
			x: 120,
			y: 120
		};
		const rect = node.getBoundingClientRect();
		return screenToWorld(rect.left + rect.width / 2, rect.top + rect.height / 2 - 40, rect, state.pan, state.zoom);
	}
	async function handleFiles(files, client) {
		const node = viewportRef.current;
		const state = useBoard.getState();
		const at = client && node ? screenToWorld(client.x, client.y, node.getBoundingClientRect(), state.pan, state.zoom) : centerWorld();
		const result = await ingestFiles(files, at);
		if (result.added) toast.success(result.added === 1 ? "Element adăugat pe pânză" : `${result.added} elemente adăugate`);
		if (result.truncatedPdf) toast.message(`Am importat primele 12 pagini din PDF.`);
		if (result.skipped) toast.error(result.skipped === 1 ? "Un fișier nu a putut fi adăugat. Folosește JPG, PNG sau PDF." : `${result.skipped} fișiere au fost omise.`);
	}
	function onFit() {
		const node = viewportRef.current;
		if (!node) return;
		fitView({
			w: node.clientWidth,
			h: node.clientHeight
		});
	}
	function onZoomBy(factor) {
		const node = viewportRef.current;
		const state = useBoard.getState();
		if (!node) return;
		const rect = node.getBoundingClientRect();
		const next = zoomToward(rect.left + rect.width / 2, rect.top + rect.height / 2, rect, state.pan, state.zoom, state.zoom * factor);
		state.setView(next.pan, next.zoom);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative h-dvh overflow-hidden bg-bg text-fg",
		onDragEnter: (event) => {
			event.preventDefault();
			dragDepth.current += 1;
			setDropping(true);
		},
		onDragLeave: (event) => {
			event.preventDefault();
			dragDepth.current = Math.max(0, dragDepth.current - 1);
			if (dragDepth.current === 0) setDropping(false);
		},
		onDragOver: (event) => event.preventDefault(),
		onDrop: (event) => {
			event.preventDefault();
			dragDepth.current = 0;
			setDropping(false);
			const files = [...event.dataTransfer.files];
			if (files.length) handleFiles(files, {
				x: event.clientX,
				y: event.clientY
			});
		},
		children: [
			ready ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BoardCanvas, {
				dropping,
				onDropFiles: (files, x, y) => void handleFiles(files, {
					x,
					y
				}),
				viewportRef
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex h-full items-center justify-center",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-4xl font-medium tracking-tight",
						children: "Tablou"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted",
						children: "Se așază pânza…"
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BoardHeader, {
				onHelp: () => setHelpOpen(true),
				onFit
			}),
			ready ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BoardToolbar, {
				onAddFiles: (files) => void handleFiles(files),
				onAddText: () => addTextAt(centerWorld().x, centerWorld().y),
				onZoomBy,
				onFit
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HelpDialog, {
				open: helpOpen,
				onOpenChange: setHelpOpen
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
				theme: "light",
				position: "top-center",
				offset: 88,
				toastOptions: {
					className: "font-sans",
					style: {
						background: "var(--color-card)",
						color: "var(--color-fg)",
						border: "1px solid var(--color-border)"
					}
				}
			})
		]
	}) });
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BoardApp, {});
}
//#endregion
export { Home as component };
